// Generate Digienglish PWA icons (PNG) using sharp
const fs = require('fs')
const path = require('path')
const sharp = require('sharp')

const ICON_SVG = (size) => `<svg width="${size}" height="${size}" viewBox="0 0 ${size} ${size}" xmlns="http://www.w3.org/2000/svg">
  <defs>
    <linearGradient id="bg" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#14B8A6"/>
      <stop offset="50%" stop-color="#0E9488"/>
      <stop offset="100%" stop-color="#0D7C70"/>
    </linearGradient>
  </defs>
  <rect width="${size}" height="${size}" rx="${size * 0.18}" fill="url(#bg)"/>
  <text x="50%" y="50%" font-family="Georgia, serif" font-size="${size * 0.55}" font-weight="700"
    text-anchor="middle" dominant-baseline="central" fill="#FCD34D">D</text>
  <rect x="${size * 0.08}" y="${size * 0.85}" width="${size * 0.84}" height="${size * 0.06}" rx="${size * 0.03}" fill="#FCD34D"/>
</svg>`

const OUT = path.join(__dirname, '..', 'public')

;(async () => {
  await sharp(Buffer.from(ICON_SVG(192))).png().toFile(path.join(OUT, 'icon-192.png'))
  await sharp(Buffer.from(ICON_SVG(512))).png().toFile(path.join(OUT, 'icon-512.png'))
  await sharp(Buffer.from(ICON_SVG(180))).png().toFile(path.join(OUT, 'apple-touch-icon.png'))
  await sharp(Buffer.from(ICON_SVG(32))).png().toFile(path.join(OUT, 'favicon-32.png'))
  console.log('Icons generated')
})().catch(e => { console.error(e); process.exit(1) })
