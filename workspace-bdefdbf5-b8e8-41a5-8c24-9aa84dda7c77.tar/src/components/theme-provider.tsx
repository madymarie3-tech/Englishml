'use client'

import { useEffect } from "react"

export function ThemeProvider({
  children,
  attribute = "class",
  defaultTheme = "light",
  enableSystem = true,
  disableTransitionOnChange = false,
}: {
  children: React.ReactNode
  attribute?: string
  defaultTheme?: string
  enableSystem?: boolean
  disableTransitionOnChange?: boolean
}) {
  useEffect(() => {
    const stored = localStorage.getItem("digi-theme")
    const theme = stored || defaultTheme
    if (attribute === "class") {
      if (theme === "dark") {
        document.documentElement.classList.add("dark")
      } else {
        document.documentElement.classList.remove("dark")
      }
    }
  }, [attribute, defaultTheme])

  return <>{children}</>
}
