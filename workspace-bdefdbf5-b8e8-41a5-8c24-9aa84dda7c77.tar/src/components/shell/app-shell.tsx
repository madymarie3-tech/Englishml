"use client"

import { useEffect, useState } from "react"
import { Home, Library, BookOpen, Brain, User as UserIcon, LayoutDashboard, Globe2, Moon, Sun } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import type { Book } from "@/lib/types"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { motion, AnimatePresence } from "framer-motion"
import { HomeSection } from "@/components/sections/home-section"
import { LibrarySection } from "@/components/sections/library/library-section"
import { ReadingView } from "@/components/sections/reading/reading-view"
import { VocabularySection } from "@/components/sections/vocabulary/vocabulary-section"
import { QuizSection } from "@/components/sections/quiz/quiz-section"
import { AccountSection } from "@/components/sections/account/account-section"
import { DashboardSection } from "@/components/sections/dashboard/dashboard-section"

export type TabKey = "home" | "library" | "reading" | "vocabulary" | "quiz" | "account" | "dashboard"

const NAV: { key: TabKey; label: keyof typeof import("@/lib/ui-text").UI; icon: any; requireAuth?: boolean }[] = [
  { key: "home", label: "navHome", icon: Home },
  { key: "library", label: "navLibrary", icon: Library },
  { key: "vocabulary", label: "navVocabulary", icon: BookOpen },
  { key: "quiz", label: "navQuiz", icon: Brain },
  { key: "dashboard", label: "navDashboard", icon: LayoutDashboard, requireAuth: true },
  { key: "account", label: "navAccount", icon: UserIcon },
]

export function AppShell() {
  const t = useT()
  const [tab, setTab] = useState<TabKey>("home")
  const [openBook, setOpenBook] = useState<Book | null>(null)
  const frenchMode = useAppStore(s => s.frenchMode)
  const darkMode = useAppStore(s => s.darkMode)
  const toggleFrenchMode = useAppStore(s => s.toggleFrenchMode)
  const toggleDarkMode = useAppStore(s => s.toggleDarkMode)
  const currentUser = useAppStore(s => s.currentUser)
  const recordVisit = useAppStore(s => s.recordVisit)

  // Track page visits
  useEffect(() => {
    recordVisit(tab)
  }, [tab, recordVisit])

  function openBookAndSwitch(book: Book) {
    setOpenBook(book)
    setTab("reading")
  }

  function navItem(key: TabKey) {
    const item = NAV.find(n => n.key === key)!
    const Icon = item.icon
    const label = t(item.label)
    const disabled = item.requireAuth && !currentUser
    return (
      <Button
        key={key}
        variant={tab === key ? "default" : "ghost"}
        size="sm"
        onClick={() => { if (!disabled) setTab(key) }}
        disabled={disabled}
        className="gap-1.5"
      >
        <Icon className="w-4 h-4" />
        <span className="hidden sm:inline">{label}</span>
      </Button>
    )
  }

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-background/85 backdrop-blur border-b border-border/60">
        <div className="h-1 mali-flag-bar" />
        <div className="container mx-auto px-4 py-3 flex items-center justify-between gap-2">
          <button
            className="flex items-center gap-2 font-bold text-lg"
            onClick={() => { setTab("home"); setOpenBook(null) }}
          >
            <div className="w-8 h-8 rounded-md bg-gradient-to-br from-primary to-primary/70 flex items-center justify-center text-primary-foreground font-serif">
              D
            </div>
            <div className="flex flex-col items-start leading-none">
              <span className="font-bold text-lg">Digi<span className="text-primary">english</span></span>
              <span className="text-[10px] font-serif italic text-muted-foreground -mt-0.5">Anglaiskalan</span>
            </div>
          </button>

          <div className="flex items-center gap-1">
            {/* Quick toggle buttons */}
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              onClick={toggleFrenchMode}
              title={t("frenchMode")}
            >
              <span className={`text-xs font-bold ${frenchMode ? "text-primary" : "text-muted-foreground"}`}>FR</span>
            </Button>
            <Button
              variant="ghost"
              size="icon"
              className="h-9 w-9"
              onClick={toggleDarkMode}
              title={t("darkMode")}
            >
              {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
            </Button>

            {/* Nav items - desktop */}
            <div className="hidden md:flex items-center gap-1 ml-2">
              {NAV.map(n => navItem(n.key))}
            </div>
          </div>
        </div>

        {/* Mobile nav */}
        <div className="md:hidden border-t border-border/60 bg-background/95 overflow-x-auto custom-scroll">
          <div className="flex items-center gap-1 px-2 py-2 min-w-max">
            {NAV.map(n => navItem(n.key))}
          </div>
        </div>
      </header>

      {/* Main content */}
      <main className="flex-1 container mx-auto px-4 py-6">
        <AnimatePresence mode="wait">
          <motion.div
            key={tab + (openBook?.id || "")}
            initial={{ opacity: 0, y: 8 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -4 }}
            transition={{ duration: 0.2 }}
          >
            {tab === "home" && <HomeSection onNavigate={setTab} />}
            {tab === "library" && <LibrarySection onOpenBook={openBookAndSwitch} />}
            {tab === "reading" && openBook && (
              <ReadingView book={openBook} onBack={() => { setTab("library"); setOpenBook(null) }} />
            )}
            {tab === "reading" && !openBook && (
              <div className="text-center py-12">
                <p className="text-muted-foreground">No book selected. <button onClick={() => setTab("library")} className="text-primary underline">Browse library</button></p>
              </div>
            )}
            {tab === "vocabulary" && <VocabularySection />}
            {tab === "quiz" && <QuizSection />}
            {tab === "account" && <AccountSection />}
            {tab === "dashboard" && currentUser && <DashboardSection />}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* Footer */}
      <footer className="mt-auto border-t border-border/60 bg-muted/30">
        <div className="h-1 mali-flag-bar" />
        <div className="container mx-auto px-4 py-4 flex items-center justify-between gap-2 flex-wrap text-xs text-muted-foreground">
          <div>
            <span className="font-semibold text-foreground">Digienglish</span> · {t("appTagline")}
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="outline" className="text-xs">v2.0</Badge>
            {currentUser ? (
              <span>{t("welcome")}, <span className="font-medium text-foreground">{currentUser.username}</span> · {currentUser.role}</span>
            ) : (
              <button onClick={() => setTab("account")} className="text-primary hover:underline">{t("signIn")}</button>
            )}
          </div>
        </div>
      </footer>
    </div>
  )
}
