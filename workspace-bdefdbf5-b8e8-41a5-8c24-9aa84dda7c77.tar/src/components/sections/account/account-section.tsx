"use client"

import { useState } from "react"
import { User as UserIcon, LogIn, LogOut, UserPlus, Shield, GraduationCap, BookOpen } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import type { Level, UserRole } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import { toast } from "sonner"

const ROLES: { value: UserRole; label: { en: string; fr: string }; icon: any }[] = [
  { value: "student", label: { en: "Student", fr: "Étudiant" }, icon: GraduationCap },
  { value: "teacher", label: { en: "Teacher", fr: "Enseignant" }, icon: BookOpen },
  { value: "admin", label: { en: "Admin", fr: "Admin" }, icon: Shield },
]
const LEVELS: Level[] = ["Beginner", "Intermediate", "Expert"]

export function AccountSection() {
  const t = useT()
  const frenchMode = useAppStore(s => s.frenchMode)
  const currentUser = useAppStore(s => s.currentUser)
  const signIn = useAppStore(s => s.signIn)
  const signUp = useAppStore(s => s.signUp)
  const signOut = useAppStore(s => s.signOut)

  // Sign-in form
  const [siUser, setSiUser] = useState("")
  const [siPass, setSiPass] = useState("")

  // Sign-up form
  const [suUser, setSuUser] = useState("")
  const [suPass, setSuPass] = useState("")
  const [suRole, setSuRole] = useState<UserRole>("student")
  const [suLevel, setSuLevel] = useState<Level>("Beginner")

  function handleSignIn() {
    const r = signIn(siUser.trim(), siPass)
    if (!r.ok) {
      toast.error(r.error || "Sign-in failed.")
    } else {
      toast.success(`${t("welcome")}, ${siUser.trim()}!`)
      setSiUser(""); setSiPass("")
    }
  }

  function handleSignUp() {
    const r = signUp({
      username: suUser.trim(),
      password: suPass,
      role: suRole,
      level: suRole === "student" ? suLevel : undefined,
    })
    if (!r.ok) {
      toast.error(r.error || "Sign-up failed.")
    } else {
      toast.success(`${t("welcome")}, ${suUser.trim()}!`)
      setSuUser(""); setSuPass("")
    }
  }

  // ===== Signed-in view =====
  if (currentUser) {
    const roleInfo = ROLES.find(r => r.value === currentUser.role)!
    const Icon = roleInfo.icon
    return (
      <div className="space-y-6 max-w-2xl mx-auto">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <UserIcon className="w-7 h-7 text-primary" />
            {t("accountTitle")}
          </h2>
        </div>
        <Card>
          <div className="h-2 mali-flag-bar" />
          <CardHeader>
            <div className="flex items-center gap-3">
              <div className="w-14 h-14 rounded-full bg-primary/10 flex items-center justify-center">
                <Icon className="w-7 h-7 text-primary" />
              </div>
              <div>
                <CardTitle>{currentUser.username}</CardTitle>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant="secondary">
                    {frenchMode ? roleInfo.label.fr : roleInfo.label.en}
                  </Badge>
                  {currentUser.level && (
                    <Badge variant="outline">{currentUser.level}</Badge>
                  )}
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="text-sm text-muted-foreground">
              {t("welcome")}, <span className="font-medium text-foreground">{currentUser.username}</span>. You are signed in as <span className="font-medium text-foreground">{frenchMode ? roleInfo.label.fr : roleInfo.label.en}</span>.
            </div>
            <Button variant="outline" onClick={() => { signOut(); toast.success("Signed out.") }}>
              <LogOut className="w-4 h-4 mr-1" /> {t("signOut")}
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // ===== Signed-out view =====
  return (
    <div className="space-y-6 max-w-2xl mx-auto">
      <div>
        <h2 className="text-3xl font-bold flex items-center gap-2">
          <UserIcon className="w-7 h-7 text-primary" />
          {t("accountTitle")}
        </h2>
        <p className="text-muted-foreground mt-1">{t("appTagline")}</p>
      </div>

      <Tabs defaultValue="signin">
        <TabsList className="w-full">
          <TabsTrigger value="signin" className="flex-1"><LogIn className="w-4 h-4 mr-1" /> {t("signIn")}</TabsTrigger>
          <TabsTrigger value="signup" className="flex-1"><UserPlus className="w-4 h-4 mr-1" /> {t("signUp")}</TabsTrigger>
        </TabsList>

        {/* Sign In */}
        <TabsContent value="signin">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="si-u">{t("username")}</Label>
                <Input id="si-u" value={siUser} onChange={e => setSiUser(e.target.value)} onKeyDown={e => e.key === "Enter" && handleSignIn()} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="si-p">{t("password")}</Label>
                <Input id="si-p" type="password" value={siPass} onChange={e => setSiPass(e.target.value)} onKeyDown={e => e.key === "Enter" && handleSignIn()} />
              </div>
              <Button className="w-full" onClick={handleSignIn}>
                <LogIn className="w-4 h-4 mr-1" /> {t("signIn")}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sign Up */}
        <TabsContent value="signup">
          <Card>
            <CardContent className="p-6 space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="su-u">{t("username")}</Label>
                <Input id="su-u" value={suUser} onChange={e => setSuUser(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="su-p">{t("password")}</Label>
                <Input id="su-p" type="password" value={suPass} onChange={e => setSuPass(e.target.value)} />
              </div>
              <div className="space-y-1.5">
                <Label>{t("role")}</Label>
                <div className="grid grid-cols-3 gap-2">
                  {ROLES.map(r => {
                    const Icon = r.icon
                    return (
                      <button
                        key={r.value}
                        onClick={() => setSuRole(r.value)}
                        className={`p-3 rounded-lg border-2 text-center transition-all ${
                          suRole === r.value
                            ? "border-primary bg-primary/5"
                            : "border-border hover:border-primary/40"
                        }`}
                      >
                        <Icon className="w-4 h-4 mx-auto mb-1" />
                        <div className="text-xs font-medium">
                          {frenchMode ? r.label.fr : r.label.en}
                        </div>
                      </button>
                    )
                  })}
                </div>
              </div>
              {suRole === "student" && (
                <div className="space-y-1.5">
                  <Label>{t("level")}</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {LEVELS.map(l => {
                      const label = l === "Beginner" ? t("levelBeginner") : l === "Intermediate" ? t("levelIntermediate") : t("levelExpert")
                      return (
                        <button
                          key={l}
                          onClick={() => setSuLevel(l)}
                          className={`p-2 rounded-lg border-2 text-center transition-all ${
                            suLevel === l
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/40"
                          }`}
                        >
                          <div className="text-xs font-medium">{label}</div>
                        </button>
                      )
                    })}
                  </div>
                </div>
              )}
              <Button className="w-full" onClick={handleSignUp}>
                <UserPlus className="w-4 h-4 mr-1" /> {t("createAccount")}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
