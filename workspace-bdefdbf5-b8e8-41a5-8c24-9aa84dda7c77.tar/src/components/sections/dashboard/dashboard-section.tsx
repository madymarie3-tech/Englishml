"use client"

import { useMemo } from "react"
import { Users, Brain, Eye, BookOpen, Trophy, ListTree, Clock, TrendingUp } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import {
  Table, TableHeader, TableRow, TableHead, TableBody, TableCell,
} from "@/components/ui/table"
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts"

export function DashboardSection() {
  const t = useT()
  const currentUser = useAppStore(s => s.currentUser)
  const users = useAppStore(s => s.users)
  const quizResults = useAppStore(s => s.quizResults)
  const pageVisits = useAppStore(s => s.pageVisits)
  const savedWords = useAppStore(s => s.savedWords)
  const readingProgress = useAppStore(s => s.readingProgress)
  const getAllBooks = useAppStore(s => s.getAllBooks)

  const books = getAllBooks()

  // Page visit aggregation for admin
  const visitStats = useMemo(() => {
    const counts: Record<string, number> = {}
    pageVisits.forEach(v => {
      counts[v.page] = (counts[v.page] || 0) + 1
    })
    return Object.entries(counts)
      .map(([page, count]) => ({ page, count }))
      .sort((a, b) => b.count - a.count)
  }, [pageVisits])

  if (!currentUser) return null

  // ===== Admin Dashboard =====
  if (currentUser.role === "admin") {
    const userResults = quizResults.filter(r => r.userId === currentUser.id)
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Users className="w-7 h-7 text-primary" />
            {t("adminDashboard")}
          </h2>
          <p className="text-muted-foreground mt-1">Manage users, view analytics and monitor quiz activity.</p>
        </div>

        {/* KPIs */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">{t("totalUsers")}</div>
                <div className="text-2xl font-bold">{users.length}</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Brain className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">{t("totalQuizzes")}</div>
                <div className="text-2xl font-bold">{quizResults.length}</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Eye className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">{t("pageVisits")}</div>
                <div className="text-2xl font-bold">{pageVisits.length}</div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* User management */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">{t("userManagement")}</CardTitle>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Username</TableHead>
                  <TableHead>Role</TableHead>
                  <TableHead>Level</TableHead>
                  <TableHead>Joined</TableHead>
                  <TableHead>Quizzes</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {users.map(u => {
                  const userQuizCount = quizResults.filter(r => r.userId === u.id).length
                  return (
                    <TableRow key={u.id}>
                      <TableCell className="font-medium">{u.username}</TableCell>
                      <TableCell>
                        <Badge variant="secondary">{u.role}</Badge>
                      </TableCell>
                      <TableCell>{u.level || "—"}</TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        {new Date(u.createdAt).toLocaleDateString()}
                      </TableCell>
                      <TableCell>{userQuizCount}</TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          </CardContent>
        </Card>

        {/* Quiz history */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">{t("quizHistory")}</CardTitle>
          </CardHeader>
          <CardContent>
            {quizResults.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t("noData")}</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>User</TableHead>
                    <TableHead>Source</TableHead>
                    <TableHead>Level</TableHead>
                    <TableHead>Score</TableHead>
                    <TableHead>Date</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {quizResults.slice().reverse().slice(0, 30).map(r => {
                    const user = users.find(u => u.id === r.userId)
                    return (
                      <TableRow key={r.id}>
                        <TableCell className="font-medium">{user?.username || "—"}</TableCell>
                        <TableCell><Badge variant="outline">{r.source}</Badge></TableCell>
                        <TableCell>{r.level}</TableCell>
                        <TableCell>
                          <Badge variant={r.percentage >= 80 ? "default" : r.percentage >= 50 ? "secondary" : "destructive"}>
                            {r.percentage}%
                          </Badge>
                        </TableCell>
                        <TableCell className="text-xs text-muted-foreground">
                          {new Date(r.date).toLocaleString()}
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>

        {/* Analytics */}
        <Card>
          <CardHeader>
            <CardTitle className="text-xl">{t("analytics")}</CardTitle>
          </CardHeader>
          <CardContent>
            {visitStats.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t("noData")}</p>
            ) : (
              <div className="space-y-3">
                <div className="h-64">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={visitStats} margin={{ top: 8, right: 16, left: 0, bottom: 8 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
                      <XAxis dataKey="page" tick={{ fontSize: 12 }} />
                      <YAxis tick={{ fontSize: 12 }} allowDecimals={false} />
                      <Tooltip />
                      <Bar dataKey="count" fill="#14B8A6" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  // ===== Teacher Dashboard =====
  if (currentUser.role === "teacher") {
    const students = users.filter(u => u.role === "student")
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <BookOpen className="w-7 h-7 text-primary" />
            {t("teacherDashboard")}
          </h2>
          <p className="text-muted-foreground mt-1">Monitor student progress and quiz performance.</p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Users className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Students</div>
                <div className="text-2xl font-bold">{students.length}</div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Brain className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Quizzes taken</div>
                <div className="text-2xl font-bold">
                  {quizResults.filter(r => students.some(s => s.id === r.userId)).length}
                </div>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-5 flex items-center gap-3">
              <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
                <Trophy className="w-6 h-6 text-primary" />
              </div>
              <div>
                <div className="text-xs text-muted-foreground">Avg. score</div>
                <div className="text-2xl font-bold">
                  {(() => {
                    const studentResults = quizResults.filter(r => students.some(s => s.id === r.userId))
                    if (studentResults.length === 0) return "—"
                    return Math.round(studentResults.reduce((s, r) => s + r.percentage, 0) / studentResults.length) + "%"
                  })()}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle className="text-xl">{t("studentProgress")}</CardTitle>
          </CardHeader>
          <CardContent>
            {students.length === 0 ? (
              <p className="text-sm text-muted-foreground">{t("noData")}</p>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Student</TableHead>
                    <TableHead>Level</TableHead>
                    <TableHead>Quizzes</TableHead>
                    <TableHead>Avg. score</TableHead>
                    <TableHead>Words saved</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {students.map(s => {
                    const sResults = quizResults.filter(r => r.userId === s.id)
                    const avg = sResults.length === 0 ? null : Math.round(sResults.reduce((sum, r) => sum + r.percentage, 0) / sResults.length)
                    // Count saved words for this user (we don't currently track per-user saved words in this demo)
                    const wordCount = savedWords.length // simplified
                    return (
                      <TableRow key={s.id}>
                        <TableCell className="font-medium">{s.username}</TableCell>
                        <TableCell><Badge variant="secondary">{s.level || "—"}</Badge></TableCell>
                        <TableCell>{sResults.length}</TableCell>
                        <TableCell>
                          {avg === null ? "—" : <Badge variant={avg >= 80 ? "default" : avg >= 50 ? "secondary" : "destructive"}>{avg}%</Badge>}
                        </TableCell>
                        <TableCell>{wordCount}</TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    )
  }

  // ===== Student Dashboard =====
  const myResults = quizResults.filter(r => r.userId === currentUser.id)
  const myProgress = Object.entries(readingProgress).filter(([k]) => k.startsWith(`${currentUser.id}:`))
  const myBooks = books.filter(b => myProgress.some(([k]) => k.endsWith(`:${b.id}`)))
  const avgScore = myResults.length === 0 ? null : Math.round(myResults.reduce((s, r) => s + r.percentage, 0) / myResults.length)

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold flex items-center gap-2">
          <Trophy className="w-7 h-7 text-primary" />
          {t("studentDashboard")}
        </h2>
        <p className="text-muted-foreground mt-1">Track your learning journey, {currentUser.username}.</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-5 flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
              <BookOpen className="w-6 h-6 text-primary" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Books in progress</div>
              <div className="text-2xl font-bold">{myBooks.length}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
              <Brain className="w-6 h-6 text-primary" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Quizzes taken</div>
              <div className="text-2xl font-bold">{myResults.length}</div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-5 flex items-center gap-3">
            <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center">
              <Trophy className="w-6 h-6 text-primary" />
            </div>
            <div>
              <div className="text-xs text-muted-foreground">Average score</div>
              <div className="text-2xl font-bold">{avgScore === null ? "—" : `${avgScore}%`}</div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{t("readingProgress")}</CardTitle>
        </CardHeader>
        <CardContent>
          {myBooks.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("noData")}</p>
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Book</TableHead>
                  <TableHead>Chapters unlocked</TableHead>
                  <TableHead>Last read</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {myBooks.map(b => {
                  const key = `${currentUser.id}:${b.id}`
                  const p = readingProgress[key]
                  return (
                    <TableRow key={b.id}>
                      <TableCell className="font-medium">
                        <span className="mr-2">{b.cover}</span>
                        {b.title}
                      </TableCell>
                      <TableCell>
                        <Badge variant="outline">
                          <ListTree className="w-3 h-3 mr-1" />
                          {p?.unlockedUpTo ?? 0} / {b.chapters.length}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">
                        <Clock className="w-3 h-3 inline mr-1" />
                        {p?.lastReadAt ? new Date(p.lastReadAt).toLocaleDateString() : "—"}
                      </TableCell>
                    </TableRow>
                  )
                })}
              </TableBody>
            </Table>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="text-xl">{t("myQuizScores")}</CardTitle>
        </CardHeader>
        <CardContent>
          {myResults.length === 0 ? (
            <p className="text-sm text-muted-foreground">{t("noData")}</p>
          ) : (
            <div className="space-y-3">
              {myResults.slice().reverse().slice(0, 10).map(r => (
                <div key={r.id} className="flex items-center justify-between p-3 rounded-lg border bg-card">
                  <div className="flex items-center gap-3">
                    <TrendingUp className="w-4 h-4 text-primary" />
                    <div>
                      <div className="text-sm font-medium">{r.source === "mywords" ? t("myWords") : t("wordLists")} · {r.level}</div>
                      <div className="text-xs text-muted-foreground">
                        {new Date(r.date).toLocaleString()} · {r.score}/{r.total}
                      </div>
                    </div>
                  </div>
                  <Badge variant={r.percentage >= 80 ? "default" : r.percentage >= 50 ? "secondary" : "destructive"}>
                    {r.percentage}%
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
