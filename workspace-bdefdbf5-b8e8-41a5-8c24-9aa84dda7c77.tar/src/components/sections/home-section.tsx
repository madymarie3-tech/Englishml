"use client"

import { motion } from "framer-motion"
import { BookOpen, Brain, Library, Trophy, Users, Sparkles, Globe2, Moon, BookMarked } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import type { TabKey } from "@/components/shell/app-shell"

interface HomeSectionProps {
  onNavigate: (tab: TabKey) => void
}

export function HomeSection({ onNavigate }: HomeSectionProps) {
  const t = useT()
  const frenchMode = useAppStore(s => s.frenchMode)
  const darkMode = useAppStore(s => s.darkMode)
  const toggleFrenchMode = useAppStore(s => s.toggleFrenchMode)
  const toggleDarkMode = useAppStore(s => s.toggleDarkMode)
  const currentUser = useAppStore(s => s.currentUser)

  const features = [
    { icon: Library, key: "library" as TabKey, title: t("navLibrary"), desc: "Browse 5 books with quizzes and reading tracking." },
    { icon: BookMarked, key: "vocabulary" as TabKey, title: t("navVocabulary"), desc: "74 curated words across 3 levels with French translations." },
    { icon: Brain, key: "quiz" as TabKey, title: t("navQuiz"), desc: "10-question quizzes that auto-switch to French after 2 wrong." },
    { icon: Users, key: "account" as TabKey, title: t("navAccount"), desc: "Student, teacher and admin accounts with dashboards." },
  ]

  return (
    <div className="space-y-8">
      {/* Hero */}
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="text-center space-y-4 py-6"
      >
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 text-primary text-xs font-medium">
          <Sparkles className="w-3 h-3" />
          Demconsult · Mali
        </div>
        <h1 className="text-5xl sm:text-6xl font-bold tracking-tight">
          Digi<span className="text-primary">english</span>
        </h1>
        <div className="text-xl sm:text-2xl font-serif italic text-accent-foreground/80 -mt-2">
          Anglaiskalan
        </div>
        <p className="text-lg text-muted-foreground max-w-xl mx-auto">
          {t("appTagline")}. Read books, learn vocabulary, take quizzes and track your progress — all in one place.
        </p>
        <div className="flex items-center justify-center gap-2 pt-2">
          <Button size="lg" onClick={() => onNavigate("library")}>
            <Library className="w-4 h-4 mr-1" /> {t("navLibrary")}
          </Button>
          <Button size="lg" variant="outline" onClick={() => onNavigate("quiz")}>
            <Brain className="w-4 h-4 mr-1" /> {t("navQuiz")}
          </Button>
        </div>

        <div className="flex items-center justify-center gap-2 pt-3">
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleFrenchMode}
            className={frenchMode ? "text-primary" : ""}
          >
            <Globe2 className="w-4 h-4 mr-1" /> {t("frenchMode")} {frenchMode ? "ON" : "OFF"}
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={toggleDarkMode}
            className={darkMode ? "text-primary" : ""}
          >
            <Moon className="w-4 h-4 mr-1" /> {t("darkMode")} {darkMode ? "ON" : "OFF"}
          </Button>
        </div>
      </motion.div>

      {/* Mali flag accent bar */}
      <div className="h-1.5 mali-flag-bar rounded-full" />

      {/* Features grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {features.map((f, i) => {
          const Icon = f.icon
          return (
            <motion.div
              key={f.key}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: i * 0.05 }}
            >
              <Card className="hover:shadow-lg hover:border-primary/40 transition-all cursor-pointer h-full" onClick={() => onNavigate(f.key)}>
                <CardContent className="p-5 flex items-start gap-4">
                  <div className="w-12 h-12 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                    <Icon className="w-6 h-6 text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="font-semibold text-lg">{f.title}</div>
                    <div className="text-sm text-muted-foreground">{f.desc}</div>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          )
        })}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {[
          { label: t("navLibrary"), value: "5", icon: Library },
          { label: t("navVocabulary"), value: "74", icon: BookOpen },
          { label: "Levels", value: "3", icon: Trophy },
          { label: t("navAccount"), value: currentUser ? currentUser.username : "—", icon: Users },
        ].map((s, i) => {
          const Icon = s.icon
          return (
            <Card key={i}>
              <CardContent className="p-4 flex items-center gap-3">
                <Icon className="w-5 h-5 text-primary" />
                <div>
                  <div className="text-xs text-muted-foreground">{s.label}</div>
                  <div className="text-lg font-bold leading-tight">{s.value}</div>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
