"use client"

import { useEffect, useMemo, useRef, useState } from "react"
import { Brain, Trophy, AlertTriangle, ArrowRight, RotateCcw, BookOpen, Check, X } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import { VOCAB_WORDS } from "@/lib/vocab-data"
import { generateQuiz, type QuizQuestion } from "@/lib/quiz-generator"
import type { Level } from "@/lib/types"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { toast } from "sonner"
import { motion, AnimatePresence } from "framer-motion"
import { v4 as uuid } from "uuid"

const LEVELS: Level[] = ["Beginner", "Intermediate", "Expert"]

export function QuizSection() {
  const t = useT()
  const frenchMode = useAppStore(s => s.frenchMode)
  const toggleFrenchMode = useAppStore(s => s.toggleFrenchMode)
  const savedWords = useAppStore(s => s.savedWords)
  const currentUser = useAppStore(s => s.currentUser)
  const addQuizResult = useAppStore(s => s.addQuizResult)

  const [phase, setPhase] = useState<"setup" | "playing" | "results">("setup")
  const [source, setSource] = useState<"mywords" | "wordlists">("wordlists")
  const [level, setLevel] = useState<Level>("Beginner")
  const [questions, setQuestions] = useState<QuizQuestion[]>([])
  const [currentIdx, setCurrentIdx] = useState(0)
  const [answers, setAnswers] = useState<Record<string, number>>({})
  const [wrongCount, setWrongCount] = useState(0)
  const [startTime, setStartTime] = useState(0)
  const [endTime, setEndTime] = useState(0)

  const pool = useMemo(() => {
    if (source === "mywords") {
      return savedWords.length >= 4 ? savedWords : []
    }
    return VOCAB_WORDS.filter(w => w.level === level)
  }, [source, savedWords, level])

  // Track whether we've auto-triggered French mode for this quiz session
  const autoFrTriggered = useRef(false)

  // If French mode is already on at the start, mark as already triggered
  useEffect(() => {
    if (frenchMode) autoFrTriggered.current = true
  }, [frenchMode])

  function maybeAutoSwitchFrench(newWrongCount: number, currentlyFrench: boolean) {
    if (newWrongCount >= 2 && !currentlyFrench && !autoFrTriggered.current) {
      autoFrTriggered.current = true
      toggleFrenchMode()
      toast.info("🔄 Mode français activé automatiquement après 2 mauvaises réponses.")
    }
  }

  function start() {
    if (pool.length < 4) {
      toast.error(t("noWordsForQuiz"))
      return
    }
    const qs = generateQuiz(pool, source === "wordlists" ? VOCAB_WORDS : savedWords)
    setQuestions(qs)
    setAnswers({})
    setWrongCount(0)
    setCurrentIdx(0)
    setStartTime(Date.now())
    autoFrTriggered.current = frenchMode
    setPhase("playing")
  }

  function answer(optionIdx: number) {
    if (answers[questions[currentIdx].id] !== undefined) return
    const q = questions[currentIdx]
    const isCorrect = optionIdx === q.correctIndex
    setAnswers(a => ({ ...a, [q.id]: optionIdx }))
    if (!isCorrect) {
      const newCount = wrongCount + 1
      setWrongCount(newCount)
      maybeAutoSwitchFrench(newCount, frenchMode)
      toast.error(t("incorrect"))
    } else {
      toast.success(t("correct"))
    }
  }

  function next() {
    if (currentIdx + 1 >= questions.length) {
      setEndTime(Date.now())
      setPhase("results")
      // Save result
      const correct = questions.filter(q => answers[q.id] === q.correctIndex).length
      if (currentUser) {
        addQuizResult({
          id: uuid(),
          userId: currentUser.id,
          source,
          level,
          score: correct,
          total: questions.length,
          percentage: Math.round((correct / questions.length) * 100),
          date: Date.now(),
          durationMs: Date.now() - startTime,
        })
      }
      return
    }
    setCurrentIdx(i => i + 1)
  }

  function reset() {
    setPhase("setup")
    setQuestions([])
    setAnswers({})
    setWrongCount(0)
    setCurrentIdx(0)
  }

  // ===== Setup screen =====
  if (phase === "setup") {
    return (
      <div className="space-y-6">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Brain className="w-7 h-7 text-primary" />
            {t("quizTitle")}
          </h2>
          <p className="text-muted-foreground mt-1">{t("quizSubtitle")}</p>
        </div>

        <Card>
          <CardContent className="p-6 space-y-6">
            <div>
              <div className="text-sm font-medium mb-2">{t("chooseSource")}</div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                <button
                  onClick={() => setSource("wordlists")}
                  className={`p-4 rounded-lg border-2 text-left transition-all ${
                    source === "wordlists"
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/40"
                  }`}
                >
                  <div className="font-medium flex items-center gap-2">
                    <BookOpen className="w-4 h-4" /> {t("wordLists")}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {VOCAB_WORDS.length} {t("chapters").replace("chapters", "words")}
                  </div>
                </button>
                <button
                  onClick={() => setSource("mywords")}
                  className={`p-4 rounded-lg border-2 text-left transition-all ${
                    source === "mywords"
                      ? "border-primary bg-primary/5"
                      : "border-border hover:border-primary/40"
                  }`}
                >
                  <div className="font-medium flex items-center gap-2">
                    <Trophy className="w-4 h-4" /> {t("myWords")}
                  </div>
                  <div className="text-xs text-muted-foreground mt-1">
                    {savedWords.length} {savedWords.length === 1 ? "word" : "words"} saved
                  </div>
                </button>
              </div>
            </div>

            <div>
              <div className="text-sm font-medium mb-2">{t("chooseLevel")}</div>
              <div className="grid grid-cols-3 gap-2">
                {LEVELS.map(l => {
                  const label = l === "Beginner" ? t("levelBeginner") : l === "Intermediate" ? t("levelIntermediate") : t("levelExpert")
                  const count = VOCAB_WORDS.filter(w => w.level === l).length
                  return (
                    <button
                      key={l}
                      onClick={() => setLevel(l)}
                      disabled={source === "mywords"}
                      className={`p-3 rounded-lg border-2 text-center transition-all disabled:opacity-50 disabled:cursor-not-allowed ${
                        level === l
                          ? "border-primary bg-primary/5"
                          : "border-border hover:border-primary/40"
                      }`}
                    >
                      <div className="font-medium text-sm">{label}</div>
                      <div className="text-xs text-muted-foreground mt-1">{count} words</div>
                    </button>
                  )
                })}
              </div>
              {source === "mywords" && (
                <p className="text-xs text-muted-foreground mt-2">
                  Level is automatically determined by your saved words.
                </p>
              )}
            </div>

            <Button onClick={start} className="w-full" size="lg">
              <Brain className="w-4 h-4 mr-2" /> {t("beginQuiz")}
            </Button>
          </CardContent>
        </Card>
      </div>
    )
  }

  // ===== Results screen =====
  if (phase === "results") {
    const correct = questions.filter(q => answers[q.id] === q.correctIndex).length
    const pct = Math.round((correct / questions.length) * 100)
    const duration = Math.round((endTime - startTime) / 1000)
    return (
      <div className="space-y-6 max-w-xl mx-auto">
        <Card className="overflow-hidden">
          <div className="h-2 mali-flag-bar" />
          <CardContent className="p-8 text-center space-y-4">
            <Trophy className={`w-16 h-16 mx-auto ${pct >= 80 ? "text-amber-500" : pct >= 50 ? "text-primary" : "text-muted-foreground"}`} />
            <div>
              <div className="text-sm text-muted-foreground">{t("results")}</div>
              <div className="text-5xl font-bold mt-2">{pct}%</div>
              <div className="text-sm text-muted-foreground mt-1">
                {t("youScored")} {correct} / {questions.length} · {duration}s
              </div>
            </div>
            <div className="flex gap-2 justify-center pt-4">
              <Button onClick={reset} variant="outline">
                <RotateCcw className="w-4 h-4 mr-1" /> {t("tryAgain")}
              </Button>
              <Button onClick={reset}>
                <BookOpen className="w-4 h-4 mr-1" /> {t("reviewWords")}
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Question review */}
        <Card>
          <CardContent className="p-4 space-y-3">
            <div className="font-medium">Review</div>
            {questions.map((q, i) => {
              const chosen = answers[q.id]
              const ok = chosen === q.correctIndex
              return (
                <div key={q.id} className="text-sm space-y-1">
                  <div className="flex items-start gap-2">
                    {ok ? <Check className="w-4 h-4 text-emerald-500 mt-0.5" /> : <X className="w-4 h-4 text-red-500 mt-0.5" />}
                    <div className="flex-1">
                      <div className="font-medium">{i + 1}. {q.prompt}</div>
                      <div className="text-xs text-muted-foreground">
                        {t("correctAnswer")} <span className="font-medium text-foreground">{q.options[q.correctIndex]}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )
            })}
          </CardContent>
        </Card>
      </div>
    )
  }

  // ===== Playing screen =====
  const q = questions[currentIdx]
  const answered = answers[q.id] !== undefined
  const chosen = answers[q.id]

  return (
    <div className="space-y-4 max-w-2xl mx-auto">
      {/* Top badges */}
      <div className="flex items-center justify-between gap-2">
        <Badge variant="outline" className="px-3 py-1">
          {t("question")} {currentIdx + 1} {t("of")} {questions.length}
        </Badge>
        <div className="flex items-center gap-2">
          <Badge variant="default" className="px-3 py-1 flex items-center gap-1">
            <Trophy className="w-3 h-3" /> {t("score")}: {questions.filter(qq => answers[qq.id] === qq.correctIndex).length}
          </Badge>
          <Badge variant={wrongCount >= 2 ? "destructive" : "outline"} className="px-3 py-1 flex items-center gap-1">
            <AlertTriangle className="w-3 h-3" /> {t("wrongAnswers")}: {wrongCount}
          </Badge>
        </div>
      </div>

      <Progress value={((currentIdx + (answered ? 1 : 0)) / questions.length) * 100} className="h-1.5" />

      {wrongCount >= 2 && (
        <motion.div
          initial={{ opacity: 0, y: -4 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-xs text-amber-600 dark:text-amber-400 italic text-center"
        >
          🇫🇷 {t("frenchMode")} activé — UI basculée en français.
        </motion.div>
      )}

      {/* Question */}
      <AnimatePresence mode="wait">
        <motion.div
          key={q.id}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          exit={{ opacity: 0, x: -20 }}
          transition={{ duration: 0.2 }}
        >
          <Card>
            <CardContent className="p-6">
              <div className="text-xs uppercase tracking-wide text-muted-foreground mb-2">
                {q.type === "definition-match" && "Definition match"}
                {q.type === "fill-blank" && "Fill in the blank"}
                {q.type === "word-match" && "Word match"}
                {q.type === "fr-en" && "🇫🇷 → 🇬🇧 FR → EN"}
              </div>
              <div className="text-lg font-medium mb-4">{q.prompt}</div>
              <div className="space-y-2">
                {q.options.map((opt, oi) => {
                  const isChosen = chosen === oi
                  const isCorrect = oi === q.correctIndex
                  const showResult = answered
                  return (
                    <button
                      key={oi}
                      disabled={answered}
                      onClick={() => answer(oi)}
                      className={`w-full text-left p-3 rounded-lg border-2 text-sm transition-all flex items-center gap-2 ${
                        showResult && isCorrect
                          ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30"
                          : showResult && isChosen && !isCorrect
                          ? "border-red-500 bg-red-50 dark:bg-red-950/30"
                          : "border-border hover:border-primary/50 hover:bg-muted/50"
                      }`}
                    >
                      <span className="font-mono text-xs w-6 h-6 rounded bg-muted flex items-center justify-center shrink-0">
                        {String.fromCharCode(65 + oi)}
                      </span>
                      <span className="flex-1">{opt}</span>
                      {showResult && isCorrect && <Check className="w-4 h-4 text-emerald-500" />}
                      {showResult && isChosen && !isCorrect && <X className="w-4 h-4 text-red-500" />}
                    </button>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </AnimatePresence>

      {answered && (
        <motion.div
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.25 }}
        >
          <Card className={`border-l-4 ${chosen === q.correctIndex ? "border-l-emerald-500 bg-emerald-50/50 dark:bg-emerald-950/20" : "border-l-amber-500 bg-amber-50/50 dark:bg-amber-950/20"}`}>
            <CardContent className="p-4 space-y-2">
              <div className="flex items-center gap-2">
                {chosen === q.correctIndex ? (
                  <><Check className="w-4 h-4 text-emerald-500" /><span className="font-medium text-emerald-700 dark:text-emerald-300">{t("correct")}</span></>
                ) : (
                  <><span className="text-base">💪</span><span className="font-medium text-amber-700 dark:text-amber-300">{t("incorrect")} {t("correctAnswer")} <span className="font-bold">{q.options[q.correctIndex]}</span></span></>
                )}
              </div>
              <div className="border-t pt-2 space-y-1.5">
                <div className="text-xs uppercase tracking-wide text-muted-foreground">🇫🇷 {t("french")}</div>
                <div className="text-base">
                  <span className="font-bold text-primary">{q.word.word}</span>
                  {q.word.frenchTranslation && (
                    <span className="text-muted-foreground mx-2">→</span>
                  )}
                  {q.word.frenchTranslation && (
                    <span className="font-medium">{q.word.frenchTranslation}</span>
                  )}
                </div>
                <div className="text-sm italic text-muted-foreground border-l-2 border-primary/30 pl-2">
                  "{q.word.example}"
                </div>
                {chosen === q.correctIndex ? (
                  <div className="text-xs text-emerald-600 dark:text-emerald-400 pt-1">
                    {frenchMode ? "Bravo ! Continuons." : "Well done! Let's keep going."}
                  </div>
                ) : (
                  <div className="text-xs text-amber-600 dark:text-amber-400 pt-1">
                    {frenchMode ? "Pas de souci — apprenez ce mot et continuez !" : "No worries — note this word and keep going!"}
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {answered && (
        <div className="flex justify-end">
          <Button onClick={next} size="lg">
            {currentIdx + 1 >= questions.length ? t("finish") : t("next")}
            <ArrowRight className="w-4 h-4 ml-1" />
          </Button>
        </div>
      )}
    </div>
  )
}
