"use client"

import { useMemo, useState } from "react"
import { ArrowLeft, ArrowRight, BookOpen, Lock, CheckCircle2 } from "lucide-react"
import type { Book } from "@/lib/types"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { toast } from "sonner"
import { motion, AnimatePresence } from "framer-motion"

interface ReadingViewProps {
  book: Book
  onBack: () => void
}

// Split text into clickable tokens (words + punctuation/whitespace preserved)
function tokenize(text: string): { value: string; isWord: boolean }[] {
  const tokens: { value: string; isWord: boolean }[] = []
  const re = /([A-Za-zÀ-ÿ'-]+)/g
  let lastIndex = 0
  let m: RegExpExecArray | null
  while ((m = re.exec(text)) !== null) {
    if (m.index > lastIndex) {
      tokens.push({ value: text.slice(lastIndex, m.index), isWord: false })
    }
    tokens.push({ value: m[0], isWord: true })
    lastIndex = m.index + m[0].length
  }
  if (lastIndex < text.length) {
    tokens.push({ value: text.slice(lastIndex), isWord: false })
  }
  return tokens
}

export function ReadingView({ book, onBack }: ReadingViewProps) {
  const t = useT()
  const currentUser = useAppStore(s => s.currentUser)
  const progressMap = useAppStore(s => s.readingProgress)
  const updateReadingProgress = useAppStore(s => s.updateReadingProgress)
  const recordChapterScore = useAppStore(s => s.recordChapterScore)
  const savedWords = useAppStore(s => s.savedWords)
  const saveWord = useAppStore(s => s.saveWord)

  const key = currentUser ? `${currentUser.id}:${book.id}` : null
  const progress = key ? progressMap[key] : undefined
  const chapterIndex = progress?.chapterIndex ?? 0
  const unlockedUpTo = progress?.unlockedUpTo ?? 0

  const [activeChapterIdx, setActiveChapterIdx] = useState(chapterIndex)
  const [wordPopup, setWordPopup] = useState<{ word: string; x: number; y: number } | null>(null)
  const [quizOpen, setQuizOpen] = useState(false)
  const [quizAnswers, setQuizAnswers] = useState<Record<string, number>>({})
  const [quizSubmitted, setQuizSubmitted] = useState(false)

  const chapter = book.chapters[activeChapterIdx]
  const isUnlocked = activeChapterIdx <= unlockedUpTo

  const tokens = useMemo(() => chapter ? tokenize(chapter.englishText) : [], [chapter])

  function gotoChapter(idx: number) {
    if (idx < 0 || idx >= book.chapters.length) return
    if (idx > unlockedUpTo) {
      toast.error(t("lockedChapter"))
      return
    }
    setActiveChapterIdx(idx)
    if (currentUser) {
      updateReadingProgress(currentUser.id, book.id, { chapterIndex: idx })
    }
    setQuizAnswers({})
    setQuizSubmitted(false)
  }

  function handleWordClick(word: string, e: React.MouseEvent) {
    setWordPopup({ word, x: e.clientX, y: e.clientY })
  }

  function saveCurrentWord() {
    if (!wordPopup) return
    const w = {
      id: `read-${wordPopup.word.toLowerCase()}`,
      word: wordPopup.word,
      definition: "(From your reading) Tap to look up in your dictionary.",
      example: `Found in "${book.title}", ${chapter?.title}`,
      frenchTranslation: "",
      level: "Beginner" as const,
      topic: "Reading",
    }
    saveWord(w)
    toast.success(`"${wordPopup.word}" saved to your vocabulary.`)
    setWordPopup(null)
  }

  function submitQuiz() {
    if (!chapter || !currentUser) return
    let correct = 0
    chapter.quiz.forEach((q, i) => {
      if (quizAnswers[q.id] === q.correctIndex) correct++
    })
    const pct = Math.round((correct / chapter.quiz.length) * 100)
    recordChapterScore(currentUser.id, book.id, chapter.id, pct)
    setQuizSubmitted(true)
    if (pct >= 80) {
      toast.success(`Great job! ${pct}% — next chapter unlocked.`)
    } else {
      toast.error(`You scored ${pct}%. You need 80% to unlock the next chapter.`)
    }
  }

  if (!chapter) return null

  const lastScore = progress?.chapterScores?.[chapter.id]

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="flex items-start justify-between gap-3 flex-wrap">
        <Button variant="ghost" size="sm" onClick={onBack}>
          <ArrowLeft className="w-4 h-4 mr-1" /> {t("backToLibrary")}
        </Button>
        <div className="text-right">
          <div className="text-sm text-muted-foreground">{book.title}</div>
          <div className="text-xs text-muted-foreground">
            {t("chapter")} {activeChapterIdx + 1} / {book.chapters.length}
          </div>
        </div>
      </div>

      {/* Chapter selector */}
      <div className="flex gap-1.5 overflow-x-auto custom-scroll pb-2">
        {book.chapters.map((c, i) => {
          const locked = i > unlockedUpTo
          return (
            <Button
              key={c.id}
              size="sm"
              variant={i === activeChapterIdx ? "default" : "outline"}
              disabled={locked}
              onClick={() => gotoChapter(i)}
              className="whitespace-nowrap"
            >
              {locked ? <Lock className="w-3 h-3 mr-1" /> : null}
              {i + 1}
            </Button>
          )
        })}
      </div>

      {!isUnlocked && (
        <Card className="border-amber-300 bg-amber-50 dark:bg-amber-950/30">
          <CardContent className="py-4 flex items-center gap-3 text-amber-700 dark:text-amber-300">
            <Lock className="w-5 h-5" />
            <span className="text-sm">{t("lockedChapter")}</span>
          </CardContent>
        </Card>
      )}

      {/* Chapter content */}
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl">{chapter.title}</CardTitle>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge variant="secondary">{book.level}</Badge>
            {lastScore !== undefined && (
              <Badge variant={lastScore >= 80 ? "default" : "destructive"} className="flex items-center gap-1">
                <CheckCircle2 className="w-3 h-3" /> {t("result")}: {lastScore}%
              </Badge>
            )}
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-xs text-muted-foreground italic">{t("tapWordHint")}</p>
          <div className="prose prose-sm dark:prose-invert max-w-none leading-relaxed text-base">
            {tokens.map((tk, i) =>
              tk.isWord ? (
                <button
                  key={i}
                  onClick={(e) => handleWordClick(tk.value, e)}
                  className="text-foreground hover:text-primary hover:underline decoration-dotted underline-offset-4 cursor-pointer transition-colors"
                >
                  {tk.value}
                </button>
              ) : (
                <span key={i}>{tk.value}</span>
              )
            )}
          </div>

          {chapter.frenchSummary && (
            <div className="mt-6 p-4 bg-muted/60 rounded-lg border-l-4 border-primary">
              <div className="text-xs font-semibold uppercase tracking-wide text-primary mb-2">
                {t("frenchSummary")}
              </div>
              <p className="text-sm leading-relaxed">{chapter.frenchSummary}</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Footer nav */}
      <div className="flex items-center justify-between gap-2">
        <Button variant="outline" onClick={() => gotoChapter(activeChapterIdx - 1)} disabled={activeChapterIdx === 0}>
          <ArrowLeft className="w-4 h-4 mr-1" /> {t("previousChapter")}
        </Button>
        <Button onClick={() => setQuizOpen(true)}>
          <BookOpen className="w-4 h-4 mr-1" /> {t("takeChapterQuiz")}
        </Button>
        <Button
          variant="outline"
          onClick={() => gotoChapter(activeChapterIdx + 1)}
          disabled={activeChapterIdx === book.chapters.length - 1 || activeChapterIdx + 1 > unlockedUpTo}
        >
          {t("nextChapter")} <ArrowRight className="w-4 h-4 ml-1" />
        </Button>
      </div>

      {/* Word popup */}
      {wordPopup && (
        <div
          className="fixed inset-0 z-50"
          onClick={() => setWordPopup(null)}
        >
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="absolute bg-popover border rounded-lg shadow-xl p-3 w-64 text-sm"
            style={{
              left: Math.min(wordPopup.x + 8, window.innerWidth - 280),
              top: Math.min(wordPopup.y + 8, window.innerHeight - 160),
            }}
            onClick={e => e.stopPropagation()}
          >
            <div className="font-semibold text-base mb-1">{wordPopup.word}</div>
            <div className="text-xs text-muted-foreground mb-2">Tap a word in the text to look it up.</div>
            <div className="flex gap-2">
              <Button size="sm" className="h-7 flex-1" onClick={saveCurrentWord}>
                Save word
              </Button>
              <Button size="sm" variant="outline" className="h-7" onClick={() => setWordPopup(null)}>
                {t("close")}
              </Button>
            </div>
          </motion.div>
        </div>
      )}

      {/* Chapter Quiz Dialog */}
      <Dialog open={quizOpen} onOpenChange={setQuizOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto custom-scroll">
          <DialogHeader>
            <DialogTitle>{t("chapterQuiz")} — {chapter.title}</DialogTitle>
            <DialogDescription>
              Answer all questions. Score ≥80% to unlock the next chapter.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            {chapter.quiz.map((q, qi) => {
              const chosen = quizAnswers[q.id]
              const isCorrect = quizSubmitted && chosen === q.correctIndex
              const isWrong = quizSubmitted && chosen !== undefined && chosen !== q.correctIndex
              return (
                <div key={q.id} className="space-y-2">
                  <div className="font-medium text-sm">
                    {qi + 1}. {q.question}
                  </div>
                  <div className="space-y-1">
                    {q.options.map((opt, oi) => {
                      const chosenThis = chosen === oi
                      const showCorrect = quizSubmitted && oi === q.correctIndex
                      return (
                        <button
                          key={oi}
                          disabled={quizSubmitted}
                          onClick={() => setQuizAnswers(a => ({ ...a, [q.id]: oi }))}
                          className={`w-full text-left p-2 rounded-md border text-sm transition-colors ${
                            showCorrect
                              ? "border-emerald-500 bg-emerald-50 dark:bg-emerald-950/30"
                              : chosenThis && isWrong
                              ? "border-red-500 bg-red-50 dark:bg-red-950/30"
                              : chosenThis
                              ? "border-primary bg-primary/5"
                              : "border-border hover:border-primary/50 hover:bg-muted/50"
                          }`}
                        >
                          <span className="font-mono text-xs mr-2">{String.fromCharCode(65 + oi)}.</span>
                          {opt}
                        </button>
                      )
                    })}
                  </div>
                  {quizSubmitted && q.explanation && (
                    <p className="text-xs text-muted-foreground italic">{q.explanation}</p>
                  )}
                </div>
              )
            })}
          </div>
          <DialogFooter>
            {quizSubmitted ? (
              <>
                <div className="text-sm mr-auto">
                  Score:{" "}
                  <span className="font-bold">
                    {Math.round(
                      (chapter.quiz.filter(q => quizAnswers[q.id] === q.correctIndex).length /
                        chapter.quiz.length) *
                        100
                    )}
                    %
                  </span>
                </div>
                <DialogClose asChild>
                  <Button variant="outline" onClick={() => { setQuizOpen(false); setQuizSubmitted(false); setQuizAnswers({}) }}>
                    {t("close")}
                  </Button>
                </DialogClose>
                <Button onClick={() => { setQuizSubmitted(false); setQuizAnswers({}) }}>
                  {t("tryAgain")}
                </Button>
              </>
            ) : (
              <>
                <DialogClose asChild>
                  <Button variant="outline">{t("cancel")}</Button>
                </DialogClose>
                <Button onClick={submitQuiz} disabled={Object.keys(quizAnswers).length < chapter.quiz.length}>
                  {t("finish")}
                </Button>
              </>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
