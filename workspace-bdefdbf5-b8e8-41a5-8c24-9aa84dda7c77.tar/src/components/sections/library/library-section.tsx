"use client"

import { useState } from "react"
import { Library, Plus, Trash2 } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useT, useIsAdmin } from "@/lib/hooks"
import type { Book } from "@/lib/types"
import { BookCard } from "./book-card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Textarea as TextareaShad } from "@/components/ui/textarea"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose,
} from "@/components/ui/dialog"
import { toast } from "sonner"
import { v4 as uuid } from "uuid"

interface LibrarySectionProps {
  onOpenBook: (book: Book) => void
}

export function LibrarySection({ onOpenBook }: LibrarySectionProps) {
  const t = useT()
  const isAdmin = useIsAdmin()
  const getAllBooks = useAppStore(s => s.getAllBooks)
  const removeCustomBook = useAppStore(s => s.removeCustomBook)
  const addCustomBook = useAppStore(s => s.addCustomBook)
  const [addOpen, setAddOpen] = useState(false)

  const [title, setTitle] = useState("")
  const [description, setDescription] = useState("")
  const [chaptersRaw, setChaptersRaw] = useState("")

  const books = getAllBooks()

  function handleAdd() {
    if (!title.trim()) {
      toast.error("Please enter a title.")
      return
    }
    const parts = chaptersRaw.split(/^---\s*$/m).map(p => p.trim()).filter(Boolean)
    if (parts.length === 0) {
      toast.error("Please add at least one chapter (separated by '---').")
      return
    }
    const chapters = parts.map((text, i) => ({
      id: `custom-${uuid().slice(0, 8)}`,
      title: `Chapter ${i + 1}`,
      englishText: text,
      frenchSummary: "",
      quiz: [
        {
          id: `q-${i}`,
          question: `What is the main idea of chapter ${i + 1}?`,
          options: [
            "It is about reading practice",
            "It is about cooking",
            "It is about sports",
            "It is about music",
          ],
          correctIndex: 0,
          explanation: "This is a custom chapter — review the text to confirm.",
        },
      ],
    }))
    const newBook: Book = {
      id: `custom-${uuid().slice(0, 12)}`,
      title: title.trim(),
      author: "Custom",
      description: description.trim() || "A custom book added by the user.",
      cover: "📖",
      color: "from-teal-500 to-emerald-700",
      isAdvanced: false,
      category: "coursebook",
      level: "Mixed",
      chapters,
    }
    addCustomBook(newBook)
    toast.success("Custom book added!")
    setTitle("")
    setDescription("")
    setChaptersRaw("")
    setAddOpen(false)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Library className="w-7 h-7 text-primary" />
            {t("libraryTitle")}
          </h2>
          <p className="text-muted-foreground mt-1">{t("librarySubtitle")} · {books.length} {t("booksAvailable")}</p>
        </div>
        {isAdmin && (
          <Button onClick={() => setAddOpen(true)}>
            <Plus className="w-4 h-4 mr-1" />
            {t("addCustomBook")}
          </Button>
        )}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {books.map(book => (
          <div key={book.id} className="relative">
            <BookCard book={book} onOpen={onOpenBook} />
            {isAdmin && book.id.startsWith("custom-") && (
              <Button
                size="sm"
                variant="destructive"
                className="absolute bottom-2 right-2 z-10 h-7 px-2"
                onClick={() => {
                  removeCustomBook(book.id)
                  toast.success("Custom book removed.")
                }}
              >
                <Trash2 className="w-3 h-3" />
              </Button>
            )}
          </div>
        ))}
      </div>

      <Dialog open={addOpen} onOpenChange={setAddOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto custom-scroll">
          <DialogHeader>
            <DialogTitle>{t("addCustomBook")}</DialogTitle>
            <DialogDescription>
              Add a custom book for your students. Separate chapters with <code className="bg-muted px-1 rounded">---</code> on its own line.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="bk-title">{t("bookTitle")}</Label>
              <Input id="bk-title" value={title} onChange={e => setTitle(e.target.value)} placeholder="My Custom Book" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bk-desc">{t("bookDescription")}</Label>
              <TextareaShad id="bk-desc" value={description} onChange={e => setDescription(e.target.value)} placeholder="Short description..." rows={2} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="bk-chap">{t("pasteChapters")}</Label>
              <Textarea
                id="bk-chap"
                value={chaptersRaw}
                onChange={e => setChaptersRaw(e.target.value)}
                placeholder={"Chapter 1 text here...\n\n---\n\nChapter 2 text here...\n\n---\n\nChapter 3 text here..."}
                rows={10}
                className="font-mono text-sm"
              />
            </div>
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">{t("cancel")}</Button>
            </DialogClose>
            <Button onClick={handleAdd}>{t("addBook")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
