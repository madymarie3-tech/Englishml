"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { BookOpen, Lock, Sparkles, Clock, ListTree } from "lucide-react"
import type { Book } from "@/lib/types"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter, DialogClose,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { toast } from "sonner"

interface BookCardProps {
  book: Book
  onOpen: (book: Book) => void
}

export function BookCard({ book, onOpen }: BookCardProps) {
  const t = useT()
  const unlocked = useAppStore(s => !book.isAdvanced || s.unlockedBookIds.includes(book.id))
  const unlockBook = useAppStore(s => s.unlockBook)
  const currentUser = useAppStore(s => s.currentUser)
  const progressMap = useAppStore(s => s.readingProgress)
  const progress = currentUser ? progressMap[`${currentUser.id}:${book.id}`] : undefined
  const pct = progress && book.chapters.length > 0
    ? Math.round((progress.unlockedUpTo / book.chapters.length) * 100)
    : 0

  const [askCode, setAskCode] = useState(false)
  const [codeInput, setCodeInput] = useState("")

  function handleClick() {
    if (book.isAdvanced && !unlocked) {
      setAskCode(true)
      return
    }
    onOpen(book)
  }

  function tryUnlock() {
    const r = unlockBook(book.id, codeInput.trim())
    if (r.ok) {
      toast.success("Book unlocked! Enjoy your reading.")
      setAskCode(false)
      setCodeInput("")
      onOpen(book)
    } else {
      toast.error(r.error || "Incorrect access code.")
    }
  }

  return (
    <>
      <motion.div
        initial={{ opacity: 0, y: 12 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.25 }}
        whileHover={{ y: -3 }}
      >
        <Card className="overflow-hidden flex flex-col h-full border-border/60 hover:shadow-lg transition-shadow">
          <div className={`h-28 bg-gradient-to-br ${book.color} flex items-center justify-center relative`}>
            <span className="text-5xl drop-shadow-sm">{book.cover}</span>
            {book.isAdvanced && !unlocked && (
              <div className="absolute top-2 right-2 bg-black/40 text-white px-2 py-1 rounded-md text-xs flex items-center gap-1">
                <Lock className="w-3 h-3" />
                {t("locked")}
              </div>
            )}
            {book.isAdvanced && unlocked && (
              <div className="absolute top-2 right-2 bg-emerald-500/90 text-white px-2 py-1 rounded-md text-xs flex items-center gap-1">
                <Sparkles className="w-3 h-3" />
                Unlocked
              </div>
            )}
          </div>
          <CardHeader className="pb-2">
            <div className="flex items-start justify-between gap-2">
              <CardTitle className="text-lg leading-tight">{book.title}</CardTitle>
            </div>
            <div className="flex flex-wrap gap-1 mt-1">
              <Badge variant="secondary" className="text-xs">{book.level}</Badge>
              <Badge variant="outline" className="text-xs flex items-center gap-1">
                <ListTree className="w-3 h-3" />
                {book.chapters.length} {t("chapters")}
              </Badge>
              {book.isAdvanced && !unlocked && (
                <Badge variant="outline" className="text-xs text-amber-600 border-amber-300">
                  🔒 {t("locked")}
                </Badge>
              )}
            </div>
          </CardHeader>
          <CardContent className="flex-1 flex flex-col gap-3">
            <p className="text-sm text-muted-foreground line-clamp-3 flex-1">{book.description}</p>

            {progress && (
              <div className="space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" /> {progress.unlockedUpTo}/{book.chapters.length}
                  </span>
                  <span className="font-medium">{pct}%</span>
                </div>
                <Progress value={pct} className="h-1.5" />
              </div>
            )}

            <Button
              className="w-full"
              variant={unlocked ? "default" : "outline"}
              onClick={handleClick}
            >
              {book.isAdvanced && !unlocked ? (
                <>
                  <Lock className="w-4 h-4 mr-1" /> {t("unlock")}
                </>
              ) : (
                <>
                  <BookOpen className="w-4 h-4 mr-1" />
                  {progress ? t("continueReading") : t("startReading")}
                </>
              )}
            </Button>
          </CardContent>
        </Card>
      </motion.div>

      <Dialog open={askCode} onOpenChange={setAskCode}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Lock className="w-5 h-5" />
              {t("locked")} — {book.title}
            </DialogTitle>
            <DialogDescription>
              {t("enterAccessCode")}. {t("unlockHint")}
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="acc-code">{t("enterAccessCode")}</Label>
            <Input
              id="acc-code"
              value={codeInput}
              onChange={e => setCodeInput(e.target.value)}
              onKeyDown={e => e.key === "Enter" && tryUnlock()}
              autoFocus
              type="password"
            />
          </div>
          <DialogFooter>
            <DialogClose asChild>
              <Button variant="outline">{t("cancel")}</Button>
            </DialogClose>
            <Button onClick={tryUnlock}>{t("unlock")}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  )
}
