"use client"

import { useMemo, useState } from "react"
import { BookMarked as VocabIcon, Search, Plus, Check, RotateCcw, ChevronLeft, ChevronRight, Trash2 } from "lucide-react"
import { useAppStore } from "@/lib/store"
import { useT } from "@/lib/hooks"
import { VOCAB_WORDS, WORD_LIST_TOPICS } from "@/lib/vocab-data"
import type { Level, VocabWord } from "@/lib/types"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs"
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select"
import { toast } from "sonner"
import { motion } from "framer-motion"

const LEVELS: (Level | "all")[] = ["all", "Beginner", "Intermediate", "Expert"]

export function VocabularySection() {
  const t = useT()
  const savedWords = useAppStore(s => s.savedWords)
  const saveWord = useAppStore(s => s.saveWord)
  const removeSavedWord = useAppStore(s => s.removeSavedWord)

  const [tab, setTab] = useState<"lists" | "mine">("lists")
  const [search, setSearch] = useState("")
  const [level, setLevel] = useState<Level | "all">("all")
  const [topic, setTopic] = useState<string>("all")
  const [flashOpen, setFlashOpen] = useState(false)
  const [flashIdx, setFlashIdx] = useState(0)
  const [flipped, setFlipped] = useState(false)

  const filtered = useMemo(() => {
    return VOCAB_WORDS.filter(w => {
      if (level !== "all" && w.level !== level) return false
      if (topic !== "all" && w.topic !== topic) return false
      if (search) {
        const s = search.toLowerCase()
        return (
          w.word.toLowerCase().includes(s) ||
          w.definition.toLowerCase().includes(s) ||
          w.frenchTranslation.toLowerCase().includes(s) ||
          w.example.toLowerCase().includes(s)
        )
      }
      return true
    })
  }, [search, level, topic])

  const filteredSaved = useMemo(() => {
    return savedWords.filter(w => {
      if (level !== "all" && w.level !== level) return false
      if (search) {
        const s = search.toLowerCase()
        return (
          w.word.toLowerCase().includes(s) ||
          w.definition.toLowerCase().includes(s) ||
          w.frenchTranslation.toLowerCase().includes(s)
        )
      }
      return true
    })
  }, [savedWords, search, level])

  const flashcards = tab === "lists" ? filtered : filteredSaved

  function openFlashcards() {
    if (flashcards.length === 0) {
      toast.error("No words to study yet.")
      return
    }
    setFlashIdx(0)
    setFlipped(false)
    setFlashOpen(true)
  }

  function nextCard() {
    setFlipped(false)
    setTimeout(() => {
      setFlashIdx(i => (i + 1) % flashcards.length)
    }, 150)
  }
  function prevCard() {
    setFlipped(false)
    setTimeout(() => {
      setFlashIdx(i => (i - 1 + flashcards.length) % flashcards.length)
    }, 150)
  }

  return (
    <div className="space-y-6">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <VocabIcon className="w-7 h-7 text-primary" />
            {t("vocabularyTitle")}
          </h2>
          <p className="text-muted-foreground mt-1">{t("vocabularySubtitle")}</p>
        </div>
        <Button onClick={openFlashcards}>
          <RotateCcw className="w-4 h-4 mr-1" />
          {t("flashcards")}
        </Button>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as "lists" | "mine")}>
        <TabsList>
          <TabsTrigger value="lists">{t("wordLists")} <Badge variant="secondary" className="ml-2">{VOCAB_WORDS.length}</Badge></TabsTrigger>
          <TabsTrigger value="mine">{t("myWords")} <Badge variant="secondary" className="ml-2">{savedWords.length}</Badge></TabsTrigger>
        </TabsList>

        {/* Filters */}
        <div className="flex gap-2 flex-wrap mt-4">
          <div className="relative flex-1 min-w-[200px]">
            <Search className="w-4 h-4 absolute left-2 top-1/2 -translate-y-1/2 text-muted-foreground" />
            <Input
              placeholder={t("search")}
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="pl-8"
            />
          </div>
          <Select value={level} onValueChange={(v) => setLevel(v as Level | "all")}>
            <SelectTrigger className="w-[150px]">
              <SelectValue placeholder={t("allLevels")} />
            </SelectTrigger>
            <SelectContent>
              {LEVELS.map(l => (
                <SelectItem key={l} value={l}>
                  {l === "all" ? t("allLevels") : l}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {tab === "lists" && (
            <Select value={topic} onValueChange={setTopic}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder={t("allTopics")} />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">{t("allTopics")}</SelectItem>
                {WORD_LIST_TOPICS.map(tp => (
                  <SelectItem key={tp} value={tp}>{tp}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          )}
        </div>

        {/* Word Lists tab */}
        <TabsContent value="lists" className="mt-4">
          {filtered.length === 0 ? (
            <Card><CardContent className="py-12 text-center text-muted-foreground">{t("noWordsFound")}</CardContent></Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filtered.map((w, i) => {
                const isSaved = savedWords.some(s => s.id === w.id)
                return (
                  <motion.div
                    key={w.id}
                    initial={{ opacity: 0, y: 8 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.2, delay: Math.min(i * 0.02, 0.3) }}
                  >
                    <Card className="h-full">
                      <CardContent className="p-4 flex flex-col gap-2 h-full">
                        <div className="flex items-start justify-between gap-2">
                          <div>
                            <div className="font-bold text-lg leading-tight">{w.word}</div>
                            <div className="text-xs text-muted-foreground">{w.frenchTranslation}</div>
                          </div>
                          <Badge variant="outline" className="text-xs">{w.level}</Badge>
                        </div>
                        <p className="text-sm">{w.definition}</p>
                        <p className="text-xs italic text-muted-foreground border-l-2 border-primary/30 pl-2">"{w.example}"</p>
                        <div className="flex items-center justify-between mt-auto pt-2">
                          <Badge variant="secondary" className="text-xs">{w.topic}</Badge>
                          {isSaved ? (
                            <Button size="sm" variant="outline" disabled className="h-7">
                              <Check className="w-3 h-3 mr-1" /> {t("saved")}
                            </Button>
                          ) : (
                            <Button size="sm" variant="default" className="h-7" onClick={() => { saveWord(w); toast.success(`"${w.word}" added.`) }}>
                              <Plus className="w-3 h-3 mr-1" /> {t("saveWord")}
                            </Button>
                          )}
                        </div>
                      </CardContent>
                    </Card>
                  </motion.div>
                )
              })}
            </div>
          )}
        </TabsContent>

        {/* My Words tab */}
        <TabsContent value="mine" className="mt-4">
          {filteredSaved.length === 0 ? (
            <Card><CardContent className="py-12 text-center text-muted-foreground">
              {savedWords.length === 0 ? t("noWordsYet") : t("noWordsFound")}
            </CardContent></Card>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {filteredSaved.map((w) => (
                <Card key={w.id}>
                  <CardContent className="p-4 flex flex-col gap-2">
                    <div className="flex items-start justify-between gap-2">
                      <div>
                        <div className="font-bold text-lg leading-tight">{w.word}</div>
                        <div className="text-xs text-muted-foreground">{w.frenchTranslation || "—"}</div>
                      </div>
                      <Badge variant="outline" className="text-xs">{w.level}</Badge>
                    </div>
                    <p className="text-sm">{w.definition}</p>
                    {w.example && (
                      <p className="text-xs italic text-muted-foreground border-l-2 border-primary/30 pl-2">"{w.example}"</p>
                    )}
                    <div className="flex items-center justify-between mt-2 pt-2 border-t">
                      <Badge variant="secondary" className="text-xs">{w.topic}</Badge>
                      <Button
                        size="sm"
                        variant="ghost"
                        className="h-7 text-destructive hover:text-destructive"
                        onClick={() => { removeSavedWord(w.id); toast.success(`"${w.word}" removed.`) }}
                      >
                        <Trash2 className="w-3 h-3 mr-1" /> {t("removeWord")}
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>

      {/* Flashcard dialog */}
      {flashOpen && flashcards.length > 0 && (
        <div className="fixed inset-0 z-50 bg-black/60 flex items-center justify-center p-4" onClick={() => setFlashOpen(false)}>
          <div className="bg-background rounded-xl shadow-2xl w-full max-w-lg p-6" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-4">
              <div>
                <div className="text-sm font-medium">{t("flashcards")}</div>
                <div className="text-xs text-muted-foreground">
                  {flashIdx + 1} / {flashcards.length} · {t("flashcardHint")}
                </div>
              </div>
              <Button size="sm" variant="ghost" onClick={() => setFlashOpen(false)}>{t("close")}</Button>
            </div>

            <div className="flashcard-container h-72 cursor-pointer" onClick={() => setFlipped(f => !f)}>
              <div className={`flashcard ${flipped ? "flipped" : ""}`}>
                <div className="flashcard-face bg-gradient-to-br from-primary/10 to-accent/10 border-2 border-primary/30 rounded-xl p-6">
                  <div className="text-xs uppercase tracking-wide text-muted-foreground mb-2">{t("level")}: {flashcards[flashIdx].level}</div>
                  <div className="text-4xl font-bold text-primary mb-3">{flashcards[flashIdx].word}</div>
                  <div className="text-sm text-muted-foreground">{flashcards[flashIdx].topic}</div>
                  <div className="text-xs italic mt-4 text-muted-foreground">Click to flip →</div>
                </div>
                <div className="flashcard-face flashcard-back bg-gradient-to-br from-accent/10 to-primary/10 border-2 border-accent/30 rounded-xl p-6">
                  <div className="text-xs uppercase tracking-wide text-muted-foreground mb-2">{t("definition")}</div>
                  <div className="text-lg font-medium mb-3">{flashcards[flashIdx].definition}</div>
                  <div className="text-xs italic text-muted-foreground border-l-2 border-primary/40 pl-2 text-left">"{flashcards[flashIdx].example}"</div>
                  <div className="text-sm mt-3"><span className="font-semibold">🇫🇷 {t("french")}:</span> {flashcards[flashIdx].frenchTranslation}</div>
                </div>
              </div>
            </div>

            <div className="flex items-center justify-between mt-4">
              <Button variant="outline" onClick={prevCard}>
                <ChevronLeft className="w-4 h-4 mr-1" /> {t("prevCard")}
              </Button>
              <Button variant="outline" onClick={() => setFlipped(f => !f)}>
                <RotateCcw className="w-4 h-4 mr-1" /> Flip
              </Button>
              <Button variant="outline" onClick={nextCard}>
                {t("nextCard")} <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
