import type { Book } from "./types"

// ============================================================
// BOOK 1: English Made Easy — Volume One (10 chapters)
// ============================================================
const BOOK1: Book = {
  id: "english-made-easy-v1",
  title: "English Made Easy",
  author: "Demconsult",
  description: "Volume One — 10 chapter-units covering everyday English: introductions, invitations, food, travel, health and more. Each chapter has English dialogue, French grammar notes and vocabulary.",
  cover: "📘",
  color: "from-emerald-500 to-teal-700",
  isAdvanced: false,
  category: "coursebook",
  level: "Beginner",
  chapters: [
    {
      id: "v1-c1",
      title: "Unit 1 — Introductions",
      englishText: `Hello! My name is Aminata. I am from Mali. I live in Bamako. I am a student. I study English because I want to travel. Nice to meet you!

Hi Aminata! I am John. I am from Canada. I am a teacher. I teach English in Bamako. Nice to meet you too!

Function: introducing yourself and others.
Grammar note: subject pronouns (I, you, he, she, we, they); the verb "to be" in the present simple.`,
      frenchSummary: `Fonction : se présenter et présenter quelqu'un.
Notes grammaticales : pronoms sujets (I, you, he, she, we, they) ; le verbe "to be" au présent simple. Utilisez "I am" pour vous présenter.`,
      quiz: [
        { id: "q1", question: "What does Aminata study?", options: ["French", "English", "Math", "History"], correctIndex: 1, explanation: "She says: 'I study English because I want to travel.'" },
        { id: "q2", question: "Where does John come from?", options: ["Mali", "USA", "Canada", "France"], correctIndex: 2, explanation: "John says: 'I am from Canada.'" },
        { id: "q3", question: "What is John's job?", options: ["Doctor", "Teacher", "Student", "Driver"], correctIndex: 1, explanation: "He says: 'I am a teacher.'" },
        { id: "q4", question: "Where does Aminata live?", options: ["Canada", "Bamako", "Paris", "London"], correctIndex: 1, explanation: "She says: 'I live in Bamako.'" },
      ],
    },
    {
      id: "v1-c2",
      title: "Unit 2 — Invitations",
      englishText: `Aminata: Would you like to come to my house for dinner on Saturday?
John: Yes, I would love to! What time?
Aminata: Around 7 PM. Is that OK for you?
John: That's perfect. Can I bring something?
Aminata: Just yourself! I will cook my favourite Malian dish.

Function: making and accepting invitations.
Grammar note: "Would you like to...?" for polite invitations; "Can I...?" for polite offers.`,
      frenchSummary: `Fonction : formuler et accepter des invitations.
Notes grammaticales : "Would you like to... ?" pour inviter poliment ; "Can I... ?" pour proposer poliment quelque chose.`,
      quiz: [
        { id: "q1", question: "What does Aminata invite John to?", options: ["Lunch", "Breakfast", "Dinner", "A movie"], correctIndex: 2, explanation: "She says: 'come to my house for dinner on Saturday'." },
        { id: "q2", question: "What time is the dinner?", options: ["5 PM", "6 PM", "7 PM", "8 PM"], correctIndex: 2, explanation: "She says: 'Around 7 PM.'" },
        { id: "q3", question: "What day is the dinner?", options: ["Friday", "Saturday", "Sunday", "Monday"], correctIndex: 1, explanation: "She says: 'on Saturday'." },
        { id: "q4", question: "What does Aminata offer to cook?", options: ["Canadian dish", "Malian dish", "French dish", "Italian dish"], correctIndex: 1, explanation: "She says: 'my favourite Malian dish.'" },
      ],
    },
    {
      id: "v1-c3",
      title: "Unit 3 — Introducing People",
      englishText: `John: Aminata, this is my friend Sarah. She is from England. She is a nurse.
Aminata: Hello Sarah, nice to meet you! Welcome to Bamako.
Sarah: Nice to meet you too, Aminata! John has told me a lot about you.
Aminata: Only good things, I hope!
Sarah: Of course! He says you are an excellent student.

Function: introducing a third person; responding politely.
Grammar note: possessive adjectives (my, your, his, her, our, their).`,
      frenchSummary: `Fonction : présenter une tierce personne et répondre poliment.
Notes grammaticales : les adjectifs possessifs (my, your, his, her, our, their).`,
      quiz: [
        { id: "q1", question: "Where is Sarah from?", options: ["Canada", "Mali", "England", "USA"], correctIndex: 2, explanation: "John says: 'She is from England.'" },
        { id: "q2", question: "What is Sarah's job?", options: ["Teacher", "Nurse", "Doctor", "Student"], correctIndex: 1, explanation: "John says: 'She is a nurse.'" },
        { id: "q3", question: "What has John told Sarah about Aminata?", options: ["She is funny", "She is tall", "She is an excellent student", "She is shy"], correctIndex: 2 },
        { id: "q4", question: "Who is introducing Sarah?", options: ["Aminata", "John", "Sarah herself", "Nobody"], correctIndex: 1 },
      ],
    },
    {
      id: "v1-c4",
      title: "Unit 4 — Small Talk",
      englishText: `Sarah: The weather is lovely today, isn't it?
Aminata: Yes, it is! Not too hot, not too cold. Perfect for a walk.
Sarah: I love Bamako at this time of year. The air is fresh in the morning.
Aminata: Do you miss England?
Sarah: Sometimes. But Mali feels like home now.

Function: making small talk about weather and feelings.
Grammar note: tag questions (isn't it?, doesn't she?); present simple for routines and facts.`,
      frenchSummary: `Fonction : faire de la "small talk" sur le temps et les sentiments.
Notes grammaticales : les tag questions (isn't it ?, doesn't she ?) ; le présent simple pour les routines et les faits.`,
      quiz: [
        { id: "q1", question: "What is the weather like?", options: ["Too hot", "Lovely", "Rainy", "Snowy"], correctIndex: 1 },
        { id: "q2", question: "What does Sarah love?", options: ["England in winter", "Bamako at this time of year", "Rain", "Cold weather"], correctIndex: 1 },
        { id: "q3", question: "When is the air fresh in Bamako?", options: ["At noon", "In the afternoon", "In the morning", "At night"], correctIndex: 2 },
        { id: "q4", question: "Does Sarah miss England?", options: ["Never", "Always", "Sometimes", "Every day"], correctIndex: 2 },
      ],
    },
    {
      id: "v1-c5",
      title: "Unit 5 — Offering Food and Drinks",
      englishText: `Aminata: Would you like some tea, Sarah?
Sarah: Yes please, that would be lovely. With a little sugar, please.
Aminata: Sure. And here are some biscuits. Help yourself!
Sarah: Thank you, Aminata. These are delicious. Did you make them?
Aminata: Yes, my mother taught me the recipe.

Function: offering food and drinks; accepting politely.
Grammar note: "some" with uncountable nouns (tea, sugar); "Would you like...?" for offers.`,
      frenchSummary: `Fonction : offrir à boire et à manger ; accepter poliment.
Notes grammaticales : "some" avec les noms indénombrables (tea, sugar) ; "Would you like... ?" pour proposer poliment.`,
      quiz: [
        { id: "q1", question: "What does Aminata offer Sarah?", options: ["Coffee", "Tea", "Juice", "Water"], correctIndex: 1 },
        { id: "q2", question: "How does Sarah take her tea?", options: ["With milk", "With sugar", "Plain", "With lemon"], correctIndex: 1 },
        { id: "q3", question: "What food does Aminata offer?", options: ["Cake", "Biscuits", "Fruit", "Bread"], correctIndex: 1 },
        { id: "q4", question: "Who taught Aminata the recipe?", options: ["Her aunt", "Her friend", "Her mother", "John"], correctIndex: 2 },
      ],
    },
    {
      id: "v1-c6",
      title: "Unit 6 — Occupations",
      englishText: `Sarah: What does your father do, Aminata?
Aminata: He is a doctor. He works at the central hospital. And your father?
Sarah: My father is an engineer. He builds bridges.
Aminata: That is impressive! And your mother?
Sarah: She is a teacher, like John. She teaches young children.

Function: talking about jobs and family.
Grammar note: present simple (he/she works, teaches); "What does [person] do?" for jobs.`,
      frenchSummary: `Fonction : parler des métiers et de la famille.
Notes grammaticales : présent simple (he/she works, teaches) ; "What does [person] do ?" pour demander le métier de quelqu'un.`,
      quiz: [
        { id: "q1", question: "What does Aminata's father do?", options: ["Engineer", "Doctor", "Teacher", "Driver"], correctIndex: 1 },
        { id: "q2", question: "Where does her father work?", options: ["At a school", "At the central hospital", "At a factory", "At home"], correctIndex: 1 },
        { id: "q3", question: "What does Sarah's father build?", options: ["Houses", "Bridges", "Cars", "Roads"], correctIndex: 1 },
        { id: "q4", question: "What does Sarah's mother teach?", options: ["Adults", "Young children", "University students", "Teenagers"], correctIndex: 1 },
      ],
    },
    {
      id: "v1-c7",
      title: "Unit 7 — Travel",
      englishText: `John: I am planning a trip to Timbuktu next month. Have you ever been there?
Aminata: Yes, I went there last year with my family. It is beautiful.
John: How did you travel? By bus or by car?
Aminata: We took the bus. It took almost ten hours, but the scenery was amazing.
John: I cannot wait to see it!

Function: talking about travel plans and past trips.
Grammar note: present continuous for future plans ("I am planning"); past simple ("went", "took").`,
      frenchSummary: `Fonction : parler de ses projets de voyage et de ses voyages passés.
Notes grammaticales : le présent continu pour les projets futurs ("I am planning") ; le prétérit ("went", "took").`,
      quiz: [
        { id: "q1", question: "Where is John planning to go?", options: ["Bamako", "Timbuktu", "Mopti", "Sikasso"], correctIndex: 1 },
        { id: "q2", question: "When is John going?", options: ["Next week", "Next month", "Next year", "Tomorrow"], correctIndex: 1 },
        { id: "q3", question: "How did Aminata travel to Timbuktu?", options: ["By car", "By bus", "By plane", "By train"], correctIndex: 1 },
        { id: "q4", question: "How long did the bus take?", options: ["Five hours", "Ten hours", "Twelve hours", "Eight hours"], correctIndex: 1 },
      ],
    },
    {
      id: "v1-c8",
      title: "Unit 8 — Health",
      englishText: `Sarah: Aminata, you look pale today. Are you alright?
Aminata: I have a headache and a sore throat. I think I am catching a cold.
Sarah: You should rest and drink plenty of water. Have you seen a doctor?
Aminata: Not yet. If I am not better tomorrow, I will go.
Sarah: Take care of yourself, my friend.

Function: asking about health; giving advice.
Grammar note: "should" for advice; first conditional ("If I am not better tomorrow, I will go").`,
      frenchSummary: `Fonction : demander comment va la santé ; donner des conseils.
Notes grammaticales : "should" pour les conseils ; le premier conditionnel ("If I am not better tomorrow, I will go").`,
      quiz: [
        { id: "q1", question: "How does Aminata look today?", options: ["Happy", "Pale", "Tired", "Excited"], correctIndex: 1 },
        { id: "q2", question: "What symptoms does Aminata have?", options: ["Stomachache", "Headache and sore throat", "Fever", "Back pain"], correctIndex: 1 },
        { id: "q3", question: "What advice does Sarah give?", options: ["Eat more", "Rest and drink water", "Go to work", "Take medicine"], correctIndex: 1 },
        { id: "q4", question: "When will Aminata see a doctor?", options: ["Today", "Tomorrow if not better", "Next week", "Never"], correctIndex: 1 },
      ],
    },
    {
      id: "v1-c9",
      title: "Unit 9 — Addresses",
      englishText: `John: Aminata, what is your address? I want to send you a book.
Aminata: I live at 24 Rue des Manguiers, Badalabougou, Bamako.
John: Is there a postal code?
Aminata: Yes, it is Bamako 3201. Thank you so much, John!
John: You are welcome. I will mail it on Monday.

Function: giving and asking for addresses.
Grammar note: prepositions of place (at, in, on); question words (what, where).`,
      frenchSummary: `Fonction : donner et demander une adresse.
Notes grammaticales : prépositions de lieu (at, in, on) ; mots interrogatifs (what, where).`,
      quiz: [
        { id: "q1", question: "What does John want to send Aminata?", options: ["A letter", "A book", "A gift", "Money"], correctIndex: 1 },
        { id: "q2", question: "What is Aminata's street number?", options: ["42", "24", "12", "7"], correctIndex: 1 },
        { id: "q3", question: "Which neighbourhood does Aminata live in?", options: ["Hamdallaye", "Badalabougou", "Magnambougou", "Faladié"], correctIndex: 1 },
        { id: "q4", question: "When will John mail the book?", options: ["Tuesday", "Monday", "Friday", "Sunday"], correctIndex: 1 },
      ],
    },
    {
      id: "v1-c10",
      title: "Unit 10 — Directions",
      englishText: `Sarah: Excuse me, can you tell me how to get to the National Museum?
Passerby: Of course. Go straight ahead for two blocks, then turn left at the traffic lights. The museum is on your right, next to the park.
Sarah: Is it far from here?
Passerby: No, about ten minutes on foot.
Sarah: Thank you very much!
Passerby: You are welcome.

Function: asking for and giving directions.
Grammar note: imperatives (go, turn, take); prepositions of movement (straight, left, right).`,
      frenchSummary: `Fonction : demander et indiquer son chemin.
Notes grammaticales : les impératifs (go, turn, take) ; les prépositions de mouvement (straight, left, right).`,
      quiz: [
        { id: "q1", question: "Where does Sarah want to go?", options: ["The market", "The National Museum", "The hospital", "The airport"], correctIndex: 1 },
        { id: "q2", question: "How many blocks should Sarah go straight?", options: ["One", "Two", "Three", "Four"], correctIndex: 1 },
        { id: "q3", question: "Where should Sarah turn left?", options: ["At the church", "At the traffic lights", "At the school", "At the bank"], correctIndex: 1 },
        { id: "q4", question: "How long does it take to walk there?", options: ["Five minutes", "Ten minutes", "Fifteen minutes", "Twenty minutes"], correctIndex: 1 },
      ],
    },
  ],
}

// ============================================================
// BOOK 2: English Made Easy — Volume Two (10 chapters, LOCKED, code 223@)
// Units 21-33 covering intermediate grammar
// ============================================================
const BOOK2: Book = {
  id: "english-made-easy-v2",
  title: "English Made Easy — Volume Two",
  author: "Demconsult",
  description: "Volume Two — 10 chapters continuing from Volume One (Units 21-33): present continuous, going-to future, comparatives, past continuous, present perfect, polite requests, would like to, used to, first conditional. LOCKED with access code.",
  cover: "📗",
  color: "from-amber-500 to-orange-700",
  isAdvanced: true,
  accessCode: "223@",
  category: "coursebook",
  level: "Intermediate",
  chapters: [
    {
      id: "v2-c1",
      title: "Unit 21 — Present Continuous",
      englishText: `Aminata is studying English right now. She is reading a chapter about verb tenses. John is helping her. They are working together at the library.

What are you doing? — I am writing an email.
What is she doing? — She is cooking dinner.
What are they doing? — They are playing football.

Function: describing actions happening now.
Grammar note: present continuous = subject + to be + verb-ing. Used for actions in progress at the moment of speaking.`,
      frenchSummary: `Fonction : décrire des actions en cours.
Notes grammaticales : présent continu = sujet + to be + verbe-ing. Utilisé pour les actions en cours au moment où l'on parle.`,
      quiz: [
        { id: "q1", question: "What is Aminata doing right now?", options: ["Sleeping", "Studying English", "Cooking", "Playing football"], correctIndex: 1 },
        { id: "q2", question: "Where are Aminata and John working?", options: ["At home", "At school", "At the library", "At the cafe"], correctIndex: 2 },
        { id: "q3", question: "What is the structure of present continuous?", options: ["subject + verb", "subject + to be + verb-ing", "subject + will + verb", "subject + have + verb-ed"], correctIndex: 1 },
        { id: "q4", question: "Which sentence is correct?", options: ["She cook dinner", "She is cooking dinner", "She cooks dinnering", "She cooking dinner"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c2",
      title: "Unit 22 — Going-to Future",
      englishText: `Aminata: What are you going to do this weekend?
John: I am going to visit my friend in Ségou. And you?
Aminata: I am going to study for my exam. Then I am going to watch a film.
John: Sounds good! We are going to meet next week, aren't we?
Aminata: Yes, on Tuesday.

Function: talking about future plans and intentions.
Grammar note: going-to future = subject + to be + going to + base verb. Used for plans and intentions.`,
      frenchSummary: `Fonction : parler de ses projets et intentions futures.
Notes grammaticales : le futur "going to" = sujet + to be + going to + verbe à l'infinitif. Utilisé pour les projets et les intentions.`,
      quiz: [
        { id: "q1", question: "What is John going to do this weekend?", options: ["Study", "Visit a friend in Ségou", "Watch a film", "Work"], correctIndex: 1 },
        { id: "q2", question: "What is Aminata going to do first?", options: ["Watch a film", "Study for her exam", "Visit a friend", "Sleep"], correctIndex: 1 },
        { id: "q3", question: "When are Aminata and John going to meet?", options: ["Monday", "Tuesday", "Friday", "Sunday"], correctIndex: 1 },
        { id: "q4", question: "Choose the correct going-to form:", options: ["I go to study", "I am going to study", "I will to study", "I going study"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c3",
      title: "Unit 23 — Comparatives",
      englishText: `The Nile is longer than the Niger River.
Mount Kilimanjaro is higher than Mount Hombori.
English is easier than Chinese, in my opinion.
Bamako is hotter than London in summer.
Sarah is taller than Aminata, but Aminata is more athletic.

Function: comparing two things or people.
Grammar note: short adjectives add -er (taller, faster); long adjectives use "more" (more beautiful, more interesting).`,
      frenchSummary: `Fonction : comparer deux choses ou personnes.
Notes grammaticales : les adjectifs courts prennent -er (taller, faster) ; les adjectifs longs utilisent "more" (more beautiful, more interesting).`,
      quiz: [
        { id: "q1", question: "Which river is longer according to the text?", options: ["The Niger", "The Nile", "The Senegal", "The Gambia"], correctIndex: 1 },
        { id: "q2", question: "Comparative form of 'tall' is:", options: ["more tall", "taller", "tallest", "most tall"], correctIndex: 1 },
        { id: "q3", question: "Comparative form of 'beautiful' is:", options: ["beautifuller", "more beautiful", "beautifullest", "beautifulmore"], correctIndex: 1 },
        { id: "q4", question: "Who is taller, Sarah or Aminata?", options: ["Aminata", "Sarah", "Same height", "Not mentioned"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c4",
      title: "Unit 24 — Past Continuous",
      englishText: `Yesterday at 6 PM, I was cooking dinner when the phone rang.
While Aminata was studying, her brother was playing outside.
They were watching TV when the lights went out.
What were you doing at 8 o'clock last night? — I was reading a book.

Function: describing actions in progress in the past.
Grammar note: past continuous = subject + was/were + verb-ing. Often used with "while" or "when".`,
      frenchSummary: `Fonction : décrire des actions en cours dans le passé.
Notes grammaticales : le prétérit continu = sujet + was/were + verbe-ing. Souvent utilisé avec "while" ou "when".`,
      quiz: [
        { id: "q1", question: "What was the speaker doing when the phone rang?", options: ["Sleeping", "Cooking dinner", "Reading", "Watching TV"], correctIndex: 1 },
        { id: "q2", question: "What was Aminata's brother doing while she was studying?", options: ["Sleeping", "Reading", "Playing outside", "Cooking"], correctIndex: 2 },
        { id: "q3", question: "What were they doing when the lights went out?", options: ["Cooking", "Reading", "Watching TV", "Eating"], correctIndex: 2 },
        { id: "q4", question: "Choose the correct past continuous form:", options: ["I cook", "I was cooking", "I cooking", "I cooked was"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c5",
      title: "Unit 25 — Present Perfect",
      englishText: `I have visited three African countries.
Aminata has lived in Bamako all her life.
John has not finished his book yet.
Have you ever eaten jollof rice? — Yes, I have.

Function: talking about past experiences with present relevance.
Grammar note: present perfect = subject + have/has + past participle. Used with "ever", "never", "already", "yet".`,
      frenchSummary: `Fonction : parler d'expériences passées avec un lien au présent.
Notes grammaticales : le present perfect = sujet + have/has + participe passé. Utilisé avec "ever", "never", "already", "yet".`,
      quiz: [
        { id: "q1", question: "How many African countries has the speaker visited?", options: ["One", "Two", "Three", "Four"], correctIndex: 2 },
        { id: "q2", question: "Where has Aminata lived all her life?", options: ["In Ségou", "In Bamako", "In Mopti", "In Kayes"], correctIndex: 1 },
        { id: "q3", question: "Has John finished his book yet?", options: ["Yes", "No", "Almost", "Almost done"], correctIndex: 1 },
        { id: "q4", question: "Choose the correct present perfect form:", options: ["I visited", "I have visited", "I visiting", "I am visited"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c6",
      title: "Unit 26 — Polite Requests",
      englishText: `Could you please open the window?
Would you mind closing the door?
Can you help me with this exercise, please?
May I borrow your pen?
Sure, here you are. / Of course. / I am sorry, I need it.

Function: making polite requests.
Grammar note: "Could you...?", "Would you mind + verb-ing...?", "May I...?" for polite forms.`,
      frenchSummary: `Fonction : formuler des demandes polies.
Notes grammaticales : "Could you... ?", "Would you mind + verbe-ing... ?", "May I... ?" pour les formes polies.`,
      quiz: [
        { id: "q1", question: "Which is the most polite request?", options: ["Open the window!", "Open the window, please.", "Could you please open the window?", "Window!"], correctIndex: 2 },
        { id: "q2", question: "After 'Would you mind', use:", options: ["base verb", "verb-ing", "to + verb", "verb-ed"], correctIndex: 1 },
        { id: "q3", question: "May I borrow your ___?", options: ["pen", "pens", "pening", "to pen"], correctIndex: 0 },
        { id: "q4", question: "If you can't help, a polite response is:", options: ["No!", "I am sorry, I need it.", "Maybe later.", "I cannot."], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c7",
      title: "Unit 27 — Would Like To",
      englishText: `I would like to travel to Japan one day.
She would like to become a doctor.
Would you like to join us for lunch?
They would like to order two teas, please.

Function: expressing wishes and desires politely.
Grammar note: would like to + base verb. Used for polite offers and wishes.`,
      frenchSummary: `Fonction : exprimer ses souhaits poliment.
Notes grammaticales : would like to + verbe à l'infinitif. Utilisé pour les offres polies et les souhaits.`,
      quiz: [
        { id: "q1", question: "Where would the speaker like to travel?", options: ["China", "Korea", "Japan", "Thailand"], correctIndex: 2 },
        { id: "q2", question: "What would she like to become?", options: ["A nurse", "A doctor", "A teacher", "An engineer"], correctIndex: 1 },
        { id: "q3", question: "After 'would like', use:", options: ["verb-ing", "to + verb", "base verb", "verb-ed"], correctIndex: 1 },
        { id: "q4", question: "What would they like to order?", options: ["Two coffees", "Two teas", "Two juices", "Two waters"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c8",
      title: "Unit 28 — Used To",
      englishText: `I used to live in a small village, but now I live in the city.
She used to play tennis every weekend, but now she prefers football.
Did you use to walk to school? — Yes, I did.
There used to be a market here, but they built a mall.

Function: talking about past habits and states that no longer exist.
Grammar note: used to + base verb; negative: didn't use to; question: Did [subject] use to...?`,
      frenchSummary: `Fonction : parler d'habitudes ou d'états passés qui ne sont plus vrais.
Notes grammaticales : used to + verbe à l'infinitif ; forme négative : didn't use to ; question : Did [sujet] use to... ?`,
      quiz: [
        { id: "q1", question: "Where did the speaker use to live?", options: ["In a city", "In a small village", "In a town", "Abroad"], correctIndex: 1 },
        { id: "q2", question: "What did she use to play every weekend?", options: ["Football", "Tennis", "Basketball", "Volleyball"], correctIndex: 1 },
        { id: "q3", question: "What did they build where the market used to be?", options: ["A school", "A mall", "A hospital", "A park"], correctIndex: 1 },
        { id: "q4", question: "Negative form of 'I used to':", options: ["I usedn't to", "I didn't use to", "I don't used to", "I not used to"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c9",
      title: "Unit 29 — First Conditional",
      englishText: `If it rains tomorrow, we will stay at home.
If you study hard, you will pass the exam.
She will be happy if you call her.
What will you do if you win the lottery? — I will travel the world.

Function: talking about possible future situations and their results.
Grammar note: first conditional = If + present simple, will + base verb.`,
      frenchSummary: `Fonction : parler de situations futures possibles et de leurs conséquences.
Notes grammaticales : le premier conditionnel = If + présent simple, will + verbe à l'infinitif.`,
      quiz: [
        { id: "q1", question: "What will they do if it rains tomorrow?", options: ["Go out", "Stay at home", "Go to school", "Play outside"], correctIndex: 1 },
        { id: "q2", question: "What will happen if you study hard?", options: ["You will fail", "You will pass the exam", "Nothing", "You will be tired"], correctIndex: 1 },
        { id: "q3", question: "First conditional structure is:", options: ["If + past, will + verb", "If + present, will + verb", "If + will, present", "If + verb-ing, will"], correctIndex: 1 },
        { id: "q4", question: "What will the speaker do if they win the lottery?", options: ["Buy a house", "Travel the world", "Save it all", "Give it away"], correctIndex: 1 },
      ],
    },
    {
      id: "v2-c10",
      title: "Unit 30 — Review & Application",
      englishText: `This week, Aminata has been practising all her new tenses. She is going to write a short story. If she finishes it by Friday, she will share it with John. She used to be shy about her English, but now she is more confident. Yesterday at 7 PM, she was writing when Sarah called.

"Hello Aminata! What are you doing?"
"I am writing a story. I would like to finish it tonight."
"Good luck! I am sure it will be wonderful."

Function: integrating present continuous, going-to future, present perfect, used to, past continuous and first conditional.
Grammar note: review all tenses from Units 21-29.`,
      frenchSummary: `Fonction : intégrer le présent continu, le futur "going to", le present perfect, "used to", le prétérit continu et le premier conditionnel.
Notes grammaticales : révision de tous les temps des unités 21 à 29.`,
      quiz: [
        { id: "q1", question: "What has Aminata been practising this week?", options: ["Vocabulary", "Her new tenses", "Pronunciation", "Reading"], correctIndex: 1 },
        { id: "q2", question: "What is she going to write?", options: ["A poem", "A short story", "A letter", "An essay"], correctIndex: 1 },
        { id: "q3", question: "When will she share it with John?", options: ["If she finishes by Friday", "Never", "Next year", "Tomorrow"], correctIndex: 0 },
        { id: "q4", question: "What was Aminata doing when Sarah called?", options: ["Sleeping", "Cooking", "Writing", "Reading"], correctIndex: 2 },
      ],
    },
  ],
}

// ============================================================
// BOOK 3: The Hidden Valley — adventure story (3 chapters, A2-B2)
// ============================================================
const BOOK3: Book = {
  id: "hidden-valley",
  title: "The Hidden Valley",
  author: "Demconsult",
  description: "A 3-chapter adventure story (A2-B2 level). Two young explorers discover a mysterious valley in the Bandiagara cliffs.",
  cover: "🏔️",
  color: "from-rose-500 to-red-700",
  isAdvanced: false,
  category: "story",
  level: "Mixed",
  chapters: [
    {
      id: "hv-c1",
      title: "Chapter 1 — The Map",
      englishText: `Kofi and Awa were sitting under the big baobab tree at the edge of their village. The afternoon sun was hot, but the shade of the tree was cool. Kofi was holding an old piece of paper he had found in his grandfather's box.

"Look at this, Awa!" he said. "It is a map. My grandfather must have drawn it many years ago."

Awa leaned over to look. The map showed the Bandiagara cliffs, and a small valley marked with a red cross. Next to the cross, in tiny handwriting, were the words: "The Hidden Valley — where the stones sing."

"The stones sing?" Awa asked, her eyes wide. "Do you think it is real?"

"My grandfather never lied," Kofi replied. "If he wrote it, then it must be true. We should go and find it."

Awa hesitated. The Bandiagara cliffs were far away, and the path was dangerous. But the mystery was too tempting. "Alright," she said finally. "We will leave at dawn."

That night, neither of them could sleep. They packed water, bread, and a small knife. Kofi also brought the map. When the first light of morning appeared, they set off toward the cliffs, their hearts full of hope and a little bit of fear.`,
      frenchSummary: `Kofi et Awa, deux jeunes du village, découvrent une vieille carte dessinée par le grand-père de Kofi. Elle indique une "vallée cachée où les pierres chantent" près des falaises de Bandiagara. Malgré le danger, ils décident de partir à l'aube pour la trouver.`,
      quiz: [
        { id: "q1", question: "Where were Kofi and Awa sitting?", options: ["In a house", "Under a baobab tree", "At school", "By the river"], correctIndex: 1 },
        { id: "q2", question: "What did Kofi find in his grandfather's box?", options: ["A book", "A map", "A knife", "A stone"], correctIndex: 1 },
        { id: "q3", question: "What did the map show?", options: ["A river", "The Bandiagara cliffs and a hidden valley", "The village", "A city"], correctIndex: 1 },
        { id: "q4", question: "What did the words next to the cross say?", options: ["The stones sing", "The wind blows", "The water runs", "The birds fly"], correctIndex: 0 },
      ],
    },
    {
      id: "hv-c2",
      title: "Chapter 2 — The Cliffs",
      englishText: `The walk to the cliffs took most of the morning. The sun climbed higher in the sky, and the air grew hotter. Kofi and Awa walked in silence, drinking small sips of water to make it last.

By midday, they reached the foot of the Bandiagara cliffs. The rock walls rose high above them, red and golden in the sunlight. Awa looked up and felt very small.

"According to the map, we need to follow the cliff to the east for about an hour," Kofi said. "Then we should see a narrow passage."

They walked along the base of the cliff. The ground was rocky and uneven. Suddenly, Awa stopped. "Kofi, listen!" she whispered.

Kofi held his breath. At first, he heard nothing. Then, very faintly, he heard a low humming sound, like a distant song carried by the wind.

"The stones are singing!" Awa said, her voice trembling with excitement.

They followed the sound. After a few minutes, they found the narrow passage between two huge rocks. They squeezed through it, and on the other side, they saw it: the Hidden Valley.

It was more beautiful than they had imagined. Green grass covered the ground, and a small waterfall sparkled in the corner. Tall stones, like ancient pillars, stood in a circle at the center. When the wind passed between them, they produced a soft, musical sound — the song of the stones.`,
      frenchSummary: `Kofi et Awa marchent jusqu'aux falaises de Bandiagara. En suivant la carte, ils entendent un étrange murmure musical porté par le vent. Ils découvrent un passage étroit et, de l'autre côté, la Vallée Cachée : un lieu magnifique avec des pierres hautes comme des piliers qui chantent quand le vent passe entre elles.`,
      quiz: [
        { id: "q1", question: "How long did the walk to the cliffs take?", options: ["An hour", "Most of the morning", "A full day", "30 minutes"], correctIndex: 1 },
        { id: "q2", question: "What direction did the map tell them to follow?", options: ["West", "North", "East", "South"], correctIndex: 2 },
        { id: "q3", question: "What sound did they hear?", options: ["Birds", "A low humming, like a song", "Thunder", "Water"], correctIndex: 1 },
        { id: "q4", question: "What was in the center of the valley?", options: ["A house", "A circle of tall stones", "A tree", "A lake"], correctIndex: 1 },
      ],
    },
    {
      id: "hv-c3",
      title: "Chapter 3 — The Secret",
      englishText: `Kofi and Awa approached the circle of singing stones slowly. The music grew louder as they got closer. In the middle of the circle, on a flat rock, they saw something shining.

It was a small medallion, made of gold, with strange symbols engraved on it. Kofi picked it up carefully. As soon as his fingers touched it, the singing stopped. The valley was completely silent.

"What did you do?" Awa asked, alarmed.

"Nothing! I just picked it up," Kofi said.

Then, a voice came from nowhere. It was old and warm, like the voice of an elder. "You have been chosen," the voice said. "That medallion has waited for many years for someone worthy. Your grandfather, Kofi, was the last guardian. Now it is your turn."

Kofi and Awa looked at each other in shock. "But... what does it mean?" Kofi asked.

"It means you must protect this valley. The stones sing because they hold the memory of our people. If they are destroyed, our history will be lost. Will you accept this responsibility?"

Awa stepped forward. "We will," she said firmly. "Together."

Kofi nodded. "Yes. We will protect the valley."

The voice seemed to smile. "Then the song will continue." And slowly, softly, the stones began to sing again.

From that day on, Kofi and Awa returned to the valley every week. They became its guardians, and they never told anyone its location. The Hidden Valley remained hidden, but its song carried on the wind, a secret melody that only the worthy could hear.`,
      frenchSummary: `Au centre du cercle de pierres, Kofi trouve une médaille en or gravée de symboles. En la touchant, le chant s'arrête et une voix ancienne leur parle : la médaille les a choisis pour être les gardiens de la vallée. Le grand-père de Kofi était le dernier gardien. Kofi et Awa acceptent la responsabilité. Désormais, ils protègent la vallée et en gardent le secret.`,
      quiz: [
        { id: "q1", question: "What did they find on the flat rock?", options: ["A book", "A gold medallion", "A knife", "A stone"], correctIndex: 1 },
        { id: "q2", question: "What happened when Kofi touched the medallion?", options: ["The singing stopped", "The valley collapsed", "The stones fell", "Nothing"], correctIndex: 0 },
        { id: "q3", question: "Whose voice spoke to them?", options: ["A child", "An old, warm voice", "A teacher", "No one"], correctIndex: 1 },
        { id: "q4", question: "Who was the last guardian before Kofi?", options: ["Awa's father", "His grandfather", "The chief", "A stranger"], correctIndex: 1 },
      ],
    },
  ],
}

// ============================================================
// BOOK 4: Everyday English Conversations (17 chapters)
// ============================================================
const everydayChapters = [
  { title: "Greetings & Hello", text: `A: Hi! How are you today?\nB: I am fine, thank you. And you?\nA: I am doing well, thanks. It is good to see you!\nB: You too. Have a nice day!\nA: You too. Goodbye!`, summary: `Salutations courantes : "How are you?", "I am fine, thank you.", "Have a nice day!" — la formule "How are you?" est une salutation polie plus qu'une vraie question sur la santé.` },
  { title: "Asking How Someone Is", text: `A: How is everything with you?\nB: Pretty good. Just busy with work.\nA: I understand. Take care of yourself.\nB: Thanks, I will. How about you?\nA: Same here — a lot to do, but fine.`, summary: `Demander comment va quelqu'un : "How is everything?", "Pretty good", "Take care of yourself" — expressions pour montrer de l'intérêt sincère.` },
  { title: "Saying Goodbye", text: `A: I have to go now. See you tomorrow!\nB: Take care! Have a safe trip home.\nA: Thank you. Bye!\nB: Bye-bye!`, summary: `Dire au revoir : "See you tomorrow", "Take care", "Have a safe trip" — diverses formules de départ selon le contexte.` },
  { title: "Shopping — At the Market", text: `A: Hello! How much are these tomatoes?\nB: Five hundred francs a kilo.\nA: I will take two kilos, please.\nB: That is one thousand francs. Anything else?\nA: No, that is all. Thank you!`, summary: `Faire les courses au marché : "How much are...?", "I will take...", "Anything else?" — vocabulaire pour acheter des produits en quantité.` },
  { title: "Shopping — Clothes", text: `A: Excuse me, do you have this shirt in blue?\nB: Let me check. Yes, here it is. What size?\nA: Medium, please. Can I try it on?\nB: Of course. The fitting room is over there.`, summary: `Acheter des vêtements : "Do you have... in [color]?", "What size?", "Can I try it on?" — vocabulaire de la boutique de prêt-à-porter.` },
  { title: "Dining — Ordering Food", text: `A: Are you ready to order?\nB: Yes. I would like the chicken with rice, please.\nA: Would you like something to drink?\nB: A bottle of water, please.\nA: Excellent. I will be right back.`, summary: `Commander au restaurant : "Are you ready to order?", "I would like...", "Would you like something to drink?" — formules polies pour commander.` },
  { title: "Dining — Paying the Bill", text: `A: Excuse me, could I have the bill, please?\nB: Of course. Here it is. Will you pay by cash or card?\nA: Card, please.\nB: Here is the machine. Thank you!\nA: Thank you. The service was excellent.`, summary: `Demander l'addition : "Could I have the bill?", "By cash or card?" — comment payer poliment et remercier.` },
  { title: "Travel — At the Airport", text: `A: Good morning. Where are you flying today?\nB: To Dakar, Senegal.\nA: May I see your passport, please?\nB: Here it is.\nA: Thank you. Your gate is B12. Boarding starts at 10:30.`, summary: `À l'aéroport : "Where are you flying today?", "May I see your passport?", "Your gate is..." — vocabulaire de l'enregistrement.` },
  { title: "Travel — At the Hotel", text: `A: Good evening. I have a reservation under the name Diarra.\nB: Welcome! Let me check. Yes, a single room for three nights.\nA: That is correct.\nB: Here is your key card. Room 204, second floor.`, summary: `À l'hôtel : "I have a reservation under the name...", "single/double room", "key card" — vocabulaire de l'hôtel.` },
  { title: "Travel — Asking for Directions", text: `A: Excuse me, how do I get to the railway station?\nB: Go straight, then turn right at the second traffic light. It is on your left.\nA: How far is it?\nB: About fifteen minutes on foot.`, summary: `Demander son chemin : "How do I get to...?", "Go straight", "turn right/left" — vocabulaire pour s'orienter en voyage.` },
  { title: "Jobs — Talking About Work", text: `A: What do you do for a living?\nB: I am a software developer. I work for a tech company.\nA: That sounds interesting. Do you enjoy it?\nB: Most days, yes. The work is challenging but rewarding.`, summary: `Parler de son travail : "What do you do for a living?", "I work for...", "challenging but rewarding" — vocabulaire professionnel courant.` },
  { title: "Health — At the Pharmacy", text: `A: Hello, how can I help you?\nB: I have a headache. Do you have something for it?\nA: Yes, these tablets are very effective. Take one every eight hours.\nB: Thank you. How much is it?`, summary: `À la pharmacie : "How can I help you?", "Do you have something for...?", "Take one every..." — vocabulaire pour demander des médicaments.` },
  { title: "Health — At the Doctor", text: `A: What seems to be the problem?\nB: I have had a cough for a week.\nA: Let me listen to your chest. Breathe in, please.\nB: Is it serious?\nA: No, just a cold. Rest and drink plenty of fluids.`, summary: `Chez le médecin : "What seems to be the problem?", "Let me listen to...", "Rest and drink plenty of fluids" — vocabulaire médical de base.` },
  { title: "Friends — Making Plans", text: `A: Are you free this Saturday?\nB: I think so. What did you have in mind?\nA: A few of us are going for a picnic by the river.\nB: Sounds great! What should I bring?`, summary: `Planifier entre amis : "Are you free...?", "What did you have in mind?", "What should I bring?" — pour organiser une sortie.` },
  { title: "Phone Calls", text: `A: Hello, this is Aminata. May I speak to John, please?\nB: Hold on, I will get him. ... John, it is for you!\nC: Hello? Hi Aminata! How are you?`, summary: `Au téléphone : "This is [name]", "May I speak to...?", "Hold on", "It is for you" — formules téléphoniques essentielles.` },
  { title: "Farewells — Saying Goodbye for a Long Time", text: `A: I cannot believe you are leaving tomorrow.\nB: I will miss you so much.\nA: Promise to write to me every week!\nB: I promise. And you must come and visit me next year.\nA: I will. Take care, my dear friend.`, summary: `Adieux longues durée : "I will miss you", "Promise to write to me", "Take care" — dire au revoir à quelqu'un qui part loin.` },
  { title: "Small Talk — Weather & Weekend", text: `A: Lovely weather today, isn't it?\nB: Yes, perfect for a walk. Did you do anything fun this weekend?\nA: I went to a concert in the park. It was amazing!\nB: That sounds wonderful. I just relaxed at home.`, summary: `Small talk : "Lovely weather, isn't it?", "Did you do anything fun this weekend?" — sujets de conversation légers et fréquents.` },
].map((c, i) => ({
  id: `everyday-c${i + 1}`,
  title: `Chapter ${i + 1} — ${c.title}`,
  englishText: c.text,
  frenchSummary: c.summary,
  quiz: [
    { id: "q1", question: `What is the topic of this chapter?`, options: [c.title, "Cooking", "Sports", "Music"], correctIndex: 0 },
    { id: "q2", question: "How many speakers are in the dialogue?", options: ["1", "2", "3", "4"], correctIndex: 1 },
  ],
}))

const BOOK4: Book = {
  id: "everyday-conversations",
  title: "Everyday English Conversations",
  author: "Demconsult",
  description: "17 chapters of daily conversations covering greetings, shopping, dining, travel, jobs, health, farewells and more — perfect for everyday use.",
  cover: "💬",
  color: "from-sky-500 to-blue-700",
  isAdvanced: false,
  category: "conversations",
  level: "Beginner",
  chapters: everydayChapters,
}

// ============================================================
// BOOK 5: Speak English Like an American (17 chapters, LOCKED, code 223@)
// ============================================================
const americanChapters = [
  { title: "Greetings in American English", text: `A: Hey, how's it going?\nB: Pretty good, thanks. You?\nA: Can't complain. Long time no see!\nB: Yeah, it's been a while. How have you been?`, summary: `Salutations américaines décontractées : "How's it going?", "Can't complain", "Long time no see" — registre informel typique américain.` },
  { title: "Making Small Talk — American Style", text: `A: So, what do you do?\nB: I'm in marketing. What about you?\nA: I'm a teacher. Hey, did you catch the game last night?\nB: Yeah, it was awesome!`, summary: `Small talk américain : "What do you do?", "Did you catch the game?" — la conversation décontractée inclut souvent le sport et le travail.` },
  { title: "Idioms — Money", text: `That'll cost you an arm and a leg.\nHe's rolling in dough.\nWe need to pinch pennies this month.\nShe makes a killing selling jewelry online.`, summary: `Idiomes américains sur l'argent : "cost an arm and a leg" (très cher), "rolling in dough" (très riche), "pinch pennies" (économiser), "make a killing" (gagner beaucoup).` },
  { title: "Idioms — Time", text: `I'll be there in a jiffy.\nWe're on the clock, so let's hurry.\nIt's high time we left.\nTake your time — there's no rush.`, summary: `Idiomes sur le temps : "in a jiffy" (tout de suite), "on the clock" (au travail/chronométré), "high time" (il est temps), "take your time" (prenez votre temps).` },
  { title: "Idioms — Feelings", text: `She's over the moon about her new job.\nHe's feeling under the weather today.\nI'm on cloud nine!\nThey're at the end of their rope.`, summary: `Idiomes de sentiments : "over the moon", "on cloud nine" (très heureux), "under the weather" (malade), "at the end of their rope" (à bout).` },
  { title: "At the Office", text: `A: Let's touch base after the meeting.\nB: Sure. I'll shoot you an email.\nA: Can you bring me up to speed on the project?\nB: Absolutely. I'll loop you in.`, summary: `Vocabulaire de bureau américain : "touch base" (faire le point), "shoot an email" (envoyer un mail), "bring up to speed" (mettre au courant), "loop in" (impliquer).` },
  { title: "Dining Out — American Style", text: `A: I'll have the burger, medium rare, with fries.\nB: Great choice. Anything to drink?\nA: A soda, please. And could I get the check?\nB: Sure thing. I'll be right back.`, summary: `Au restaurant américain : "medium rare" (saignant), "soda", "the check" (l'addition) — commandes courantes aux États-Unis.` },
  { title: "Asking for Favors", text: `A: Can you do me a favor?\nB: Sure, what's up?\nA: Could you cover for me at the meeting?\nB: No problem, I've got your back.`, summary: `Demander une faveur : "Can you do me a favor?", "What's up?", "Cover for me" (remplacer), "I've got your back" (je te soutiens).` },
  { title: "Disagreeing Politely", text: `A: I think we should go with plan A.\nB: I see your point, but I'm not so sure.\nA: What's your take?\nB: I'd lean toward plan B, to be honest.`, summary: `Exprimer un désaccord poli : "I see your point, but...", "What's your take?", "I'd lean toward..." — formules pour nuancer.` },
  { title: "Complimenting People", text: `A: I love your outfit!\nB: Oh, thanks! That's so sweet of you.\nA: You really nailed that presentation.\nB: I appreciate that. I worked hard on it.`, summary: `Faire des compliments : "I love your...", "That's so sweet", "You really nailed..." (tu as vraiment réussi) — vocabulaire américain chaleureux.` },
  { title: "Shopping — American Mall", text: `A: Excuse me, where's the food court?\nB: Second floor, right next to the cinema.\nA: And is there a sale going on?\nB: Yeah, buy one get one free on all T-shirts.`, summary: `Au centre commercial américain : "food court", "buy one get one free" (BOGO) — expressions typiques des malls.` },
  { title: "Traveling in the US", text: `A: I need to rent a car for the weekend.\nB: Sure. Do you want insurance with that?\nA: Yes, please. And what's the speed limit on highways?\nB: Usually 65 or 70 miles per hour.`, summary: `Voyager aux US : "rent a car", "insurance", "speed limit", "miles per hour" — vocabulaire pratique pour un road trip.` },
  { title: "At the Airport — American Style", text: `A: Please remove your shoes and belt.\nB: Sure. Do I need to take out my laptop?\nA: Yes, place it in a separate bin.\nB: Got it. Thanks.`, summary: `À l'aéroport américain : "remove your shoes and belt", "separate bin" — procédures typiques de la TSA.` },
  { title: "Talking About Sports", text: `A: Did you see the game last night?\nB: Yeah, it was a blowout! 30-7!\nA: They're having a great season.\nB: No doubt. They could go all the way.`, summary: `Parler de sport : "blowout" (victoire écrasante), "great season", "go all the way" (aller jusqu'au bout) — idiomes sportifs courants.` },
  { title: "Expressing Surprise", text: `No way!\nYou've got to be kidding me!\nThat's unreal!\nI can't believe my ears!`, summary: `Exprimer la surprise : "No way!", "You've got to be kidding me!", "That's unreal!", "I can't believe my ears!" — exclamation américaines typiques.` },
  { title: "Asking for Clarification", text: `A: What do you mean by that?\nB: Let me put it another way.\nA: I'm not sure I follow.\nB: In other words, we need more time.`, summary: `Demander des éclaircissements : "What do you mean?", "Let me put it another way", "I'm not sure I follow", "In other words..."` },
  { title: "Final Review — Speaking Like an American", text: `A: Hey, what's up? Long time no see!\nB: I know! It's been ages. How've you been?\nA: Can't complain. Work's been crazy, but I'm hanging in there.\nB: Good to hear. Hey, let's grab a coffee sometime and catch up.\nA: Sounds like a plan. I'll shoot you a text.`, summary: `Révision finale : "What's up?", "It's been ages", "Can't complain", "hanging in there", "grab a coffee", "catch up", "Sounds like a plan", "shoot a text" — toutes les expressions essentielles du registre américain décontracté.` },
].map((c, i) => ({
  id: `american-c${i + 1}`,
  title: `Chapter ${i + 1} — ${c.title}`,
  englishText: c.text,
  frenchSummary: c.summary,
  quiz: [
    { id: "q1", question: `What is this chapter about?`, options: [c.title, "Cooking", "Sports news", "History"], correctIndex: 0 },
    { id: "q2", question: "What style of English does this chapter teach?", options: ["Formal British", "Casual American", "Academic", "Old English"], correctIndex: 1 },
    { id: "q3", question: "How many speakers in the main dialogue?", options: ["1", "2", "3", "4"], correctIndex: 1 },
  ],
}))

const BOOK5: Book = {
  id: "speak-like-american",
  title: "Speak English Like an American",
  author: "Demconsult",
  description: "17 chapters of advanced conversations, idioms and casual American English. LOCKED with access code.",
  cover: "🇺🇸",
  color: "from-purple-500 to-fuchsia-700",
  isAdvanced: true,
  accessCode: "223@",
  category: "advanced",
  level: "Expert",
  chapters: americanChapters,
}

export const BUILT_IN_BOOKS: Book[] = [BOOK1, BOOK2, BOOK3, BOOK4, BOOK5]
