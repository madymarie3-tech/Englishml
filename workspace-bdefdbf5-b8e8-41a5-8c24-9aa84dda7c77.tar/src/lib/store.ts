import { create } from "zustand"
import { persist } from "zustand/middleware"
import type {
  Book,
  Level,
  PageVisit,
  QuizResult,
  ReadingProgress,
  SavedWord,
  User,
  UserRole,
  VocabWord,
} from "./types"
import { BUILT_IN_BOOKS } from "./books-data"
import { VOCAB_WORDS } from "./vocab-data"

// Default admin account
const DEFAULT_ADMIN: User = {
  id: "admin-default",
  username: "70441544",
  password: "Madyb223@..",
  role: "admin",
  createdAt: Date.now(),
}

interface AppState {
  // Auth
  currentUser: User | null
  users: User[]
  signUp: (data: { username: string; password: string; role: UserRole; level?: Level }) => { ok: boolean; error?: string }
  signIn: (username: string, password: string) => { ok: boolean; error?: string }
  signOut: () => void

  // Books
  customBooks: Book[]
  addCustomBook: (book: Book) => void
  removeCustomBook: (bookId: string) => void
  getAllBooks: () => Book[]

  // Locked books access codes (per book, stored once unlocked)
  unlockedBookIds: string[]
  unlockBook: (bookId: string, code: string) => { ok: boolean; error?: string }

  // Reading progress (keyed by userId:bookId)
  readingProgress: Record<string, ReadingProgress>
  updateReadingProgress: (userId: string, bookId: string, update: Partial<ReadingProgress>) => void
  recordChapterScore: (userId: string, bookId: string, chapterId: string, score: number) => void

  // Vocabulary — saved personal words
  savedWords: SavedWord[]
  saveWord: (word: VocabWord) => void
  removeSavedWord: (wordId: string) => void
  isWordSaved: (wordId: string) => boolean

  // Quiz results
  quizResults: QuizResult[]
  addQuizResult: (result: QuizResult) => void

  // Page visits (analytics)
  pageVisits: PageVisit[]
  recordVisit: (page: string) => void

  // UI
  frenchMode: boolean
  toggleFrenchMode: () => void
  darkMode: boolean
  toggleDarkMode: () => void
}

export const useAppStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUser: null,
      users: [DEFAULT_ADMIN],
      signUp: ({ username, password, role, level }) => {
        const exists = get().users.some(u => u.username.toLowerCase() === username.toLowerCase())
        if (exists) return { ok: false, error: "Username already exists." }
        if (password.length < 4) return { ok: false, error: "Password must be at least 4 characters." }
        const newUser: User = {
          id: `user-${Date.now()}`,
          username,
          password,
          role,
          level: role === "student" ? (level || "Beginner") : undefined,
          createdAt: Date.now(),
        }
        set(s => ({ users: [...s.users, newUser], currentUser: newUser }))
        return { ok: true }
      },
      signIn: (username, password) => {
        const u = get().users.find(u => u.username.toLowerCase() === username.toLowerCase() && u.password === password)
        if (!u) return { ok: false, error: "Invalid username or password." }
        set({ currentUser: u })
        return { ok: true }
      },
      signOut: () => set({ currentUser: null }),

      customBooks: [],
      addCustomBook: (book) => set(s => ({ customBooks: [...s.customBooks, book] })),
      removeCustomBook: (bookId) => set(s => ({ customBooks: s.customBooks.filter(b => b.id !== bookId) })),
      getAllBooks: () => [...BUILT_IN_BOOKS, ...get().customBooks],

      unlockedBookIds: [],
      unlockBook: (bookId, code) => {
        const book = get().getAllBooks().find(b => b.id === bookId)
        if (!book) return { ok: false, error: "Book not found." }
        if (!book.isAdvanced) return { ok: true }
        if (book.accessCode && book.accessCode !== code) {
          return { ok: false, error: "Incorrect access code." }
        }
        set(s => ({ unlockedBookIds: s.unlockedBookIds.includes(bookId) ? s.unlockedBookIds : [...s.unlockedBookIds, bookId] }))
        return { ok: true }
      },

      readingProgress: {},
      updateReadingProgress: (userId, bookId, update) => {
        const key = `${userId}:${bookId}`
        set(s => {
          const existing = s.readingProgress[key] || {
            userId, bookId, chapterIndex: 0, unlockedUpTo: 0, lastReadAt: Date.now(), chapterScores: {},
          }
          return {
            readingProgress: {
              ...s.readingProgress,
              [key]: { ...existing, ...update, lastReadAt: Date.now() },
            },
          }
        })
      },
      recordChapterScore: (userId, bookId, chapterId, score) => {
        const key = `${userId}:${bookId}`
        set(s => {
          const existing = s.readingProgress[key] || {
            userId, bookId, chapterIndex: 0, unlockedUpTo: 0, lastReadAt: Date.now(), chapterScores: {},
          }
          const prevBest = existing.chapterScores[chapterId] || 0
          const newScores = { ...existing.chapterScores, [chapterId]: Math.max(prevBest, score) }
          // Unlock next chapter if score >= 80
          let unlockedUpTo = existing.unlockedUpTo
          const book = s.getAllBooks().find(b => b.id === bookId)
          if (book && score >= 80) {
            const chapterIdx = book.chapters.findIndex(c => c.id === chapterId)
            if (chapterIdx >= 0) {
              unlockedUpTo = Math.max(existing.unlockedUpTo, chapterIdx + 1)
            }
          }
          return {
            readingProgress: {
              ...s.readingProgress,
              [key]: { ...existing, chapterScores: newScores, unlockedUpTo, lastReadAt: Date.now() },
            },
          }
        })
      },

      savedWords: [],
      saveWord: (word) => set(s => {
        if (s.savedWords.some(w => w.id === word.id)) return s
        return { savedWords: [...s.savedWords, { ...word, savedAt: Date.now() }] }
      }),
      removeSavedWord: (wordId) => set(s => ({ savedWords: s.savedWords.filter(w => w.id !== wordId) })),
      isWordSaved: (wordId) => get().savedWords.some(w => w.id === wordId),

      quizResults: [],
      addQuizResult: (result) => set(s => ({ quizResults: [...s.quizResults, result] })),

      pageVisits: [],
      recordVisit: (page) => set(s => ({
        pageVisits: [...s.pageVisits.slice(-499), { page, ts: Date.now(), userId: s.currentUser?.id }],
      })),

      frenchMode: false,
      toggleFrenchMode: () => set(s => ({ frenchMode: !s.frenchMode })),
      darkMode: false,
      toggleDarkMode: () => {
        const next = !get().darkMode
        if (typeof document !== "undefined") {
          if (next) document.documentElement.classList.add("dark")
          else document.documentElement.classList.remove("dark")
        }
        set({ darkMode: next })
      },
    }),
    {
      name: "digienglish-store",
      // Persist everything except transient UI bits
      partialize: (s) => ({
        currentUser: s.currentUser,
        users: s.users,
        customBooks: s.customBooks,
        unlockedBookIds: s.unlockedBookIds,
        readingProgress: s.readingProgress,
        savedWords: s.savedWords,
        quizResults: s.quizResults,
        pageVisits: s.pageVisits,
        frenchMode: s.frenchMode,
        darkMode: s.darkMode,
      }),
    }
  )
)

// Sync dark mode from store to <html> on first client load
if (typeof window !== "undefined") {
  const applyTheme = () => {
    const dark = useAppStore.getState().darkMode
    if (dark) document.documentElement.classList.add("dark")
    else document.documentElement.classList.remove("dark")
  }
  // Run after hydration
  setTimeout(applyTheme, 0)
}
