"use client"

import { useAppStore } from "@/lib/store"
import { t as translate, UIKey } from "@/lib/ui-text"

// Convenience hook to access UI translation in any client component
export function useT() {
  const frenchMode = useAppStore(s => s.frenchMode)
  return (key: UIKey) => translate(key, frenchMode)
}

export function useIsAdmin() {
  const user = useAppStore(s => s.currentUser)
  return user?.role === "admin"
}
