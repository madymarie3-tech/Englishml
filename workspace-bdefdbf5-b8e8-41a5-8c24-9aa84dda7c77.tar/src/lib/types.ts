// Type definitions for Digienglish

export type Level = "Beginner" | "Intermediate" | "Expert"

export type UserRole = "student" | "teacher" | "admin"

export interface User {
  id: string
  username: string
  password: string // plain for demo; in production hash
  role: UserRole
  level?: Level
  createdAt: number
}

export interface BookChapter {
  id: string
  title: string
  englishText: string
  frenchSummary: string
  quiz: ChapterQuizQuestion[]
}

export interface ChapterQuizQuestion {
  id: string
  question: string
  options: string[]
  correctIndex: number
  explanation?: string
}

export interface Book {
  id: string
  title: string
  author: string
  description: string
  cover: string // emoji or short tag
  color: string // tailwind gradient classes
  isAdvanced: boolean
  accessCode?: string
  category: "coursebook" | "story" | "conversations" | "advanced"
  level: Level | "Mixed"
  chapters: BookChapter[]
}

export interface VocabWord {
  id: string
  word: string
  definition: string
  example: string
  frenchTranslation: string
  level: Level
  topic: string
}

export interface SavedWord extends VocabWord {
  savedAt: number
}

export interface QuizResult {
  id: string
  userId: string
  source: "mywords" | "wordlists"
  level: Level
  score: number
  total: number
  percentage: number
  date: number
  durationMs: number
}

export interface ReadingProgress {
  userId: string
  bookId: string
  chapterIndex: number
  unlockedUpTo: number
  lastReadAt: number
  chapterScores: Record<string, number> // chapterId -> best %
}

export interface PageVisit {
  page: string
  ts: number
  userId?: string
}
