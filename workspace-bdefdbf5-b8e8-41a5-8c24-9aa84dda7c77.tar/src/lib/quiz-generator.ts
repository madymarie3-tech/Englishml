import type { Level, VocabWord } from "./types"

export type QuestionType = "definition-match" | "fill-blank" | "word-match" | "fr-en"

export interface QuizQuestion {
  id: string
  type: QuestionType
  prompt: string
  options: string[]
  correctIndex: number
  word: VocabWord
}

function shuffle<T>(arr: T[]): T[] {
  const a = [...arr]
  for (let i = a.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[a[i], a[j]] = [a[j], a[i]]
  }
  return a
}

function pickDistractors<T>(pool: T[], correct: T, count: number): T[] {
  return shuffle(pool.filter(x => x !== correct)).slice(0, count)
}

const FILL_BLANK_TEMPLATES = [
  (w: VocabWord) => w.example.replace(new RegExp(w.word, "i"), "_____"),
]

/**
 * Generate a 10-question quiz from the given word pool.
 * Question types are distributed roughly evenly:
 *   - definition-match (which definition matches this word?)
 *   - fill-blank (sentence with word removed)
 *   - word-match (which word matches this definition?)
 *   - fr-en (French -> English)
 */
export function generateQuiz(words: VocabWord[], allWords: VocabWord[] = words): QuizQuestion[] {
  if (words.length === 0) return []
  const target = Math.min(10, words.length)
  const picked = shuffle(words).slice(0, target)
  const types: QuestionType[] = ["definition-match", "fill-blank", "word-match", "fr-en"]

  return picked.map((w, i) => {
    const type = types[i % types.length]
    // For distractors, we want OTHER words (different from w)
    const distractorPool = allWords.filter(x => x.id !== w.id)

    if (type === "definition-match") {
      // Q: "Which definition matches this word: <word>?"
      const distractors = pickDistractors(distractorPool.map(d => d.definition), w.definition, 3)
      const options = shuffle([w.definition, ...distractors])
      return {
        id: `q-${i}`,
        type,
        prompt: `Which definition matches this word: "${w.word}"?`,
        options,
        correctIndex: options.indexOf(w.definition),
        word: w,
      }
    }

    if (type === "fill-blank") {
      // Sentence with the target word blanked out.
      const template = FILL_BLANK_TEMPLATES[Math.floor(Math.random() * FILL_BLANK_TEMPLATES.length)]
      const sentence = template(w)
      const distractors = pickDistractors(distractorPool.map(d => d.word), w.word, 3)
      const options = shuffle([w.word, ...distractors])
      return {
        id: `q-${i}`,
        type,
        prompt: `Fill in the blank: ${sentence}`,
        options,
        correctIndex: options.indexOf(w.word),
        word: w,
      }
    }

    if (type === "word-match") {
      // Q: "Which word matches this definition: <definition>?"
      const distractors = pickDistractors(distractorPool.map(d => d.word), w.word, 3)
      const options = shuffle([w.word, ...distractors])
      return {
        id: `q-${i}`,
        type,
        prompt: `Which word matches this definition: "${w.definition}"?`,
        options,
        correctIndex: options.indexOf(w.word),
        word: w,
      }
    }

    // fr-en
    const distractors = pickDistractors(distractorPool.map(d => d.word), w.word, 3)
    const options = shuffle([w.word, ...distractors])
    return {
      id: `q-${i}`,
      type,
      prompt: `The French word "${w.frenchTranslation}" means which English word?`,
      options,
      correctIndex: options.indexOf(w.word),
      word: w,
    }
  })
}

export function filterByLevel(words: VocabWord[], level: Level | "all"): VocabWord[] {
  if (level === "all") return words
  return words.filter(w => w.level === level)
}
