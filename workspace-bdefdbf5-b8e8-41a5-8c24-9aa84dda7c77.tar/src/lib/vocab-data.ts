import type { VocabWord } from "./types"

// 74 curated words across 3 levels
export const VOCAB_WORDS: VocabWord[] = [
  // ===== BEGINNER (28 words) =====
  // Greetings
  { id: "b1", word: "Hello", definition: "A common greeting", example: "Hello, how are you today?", frenchTranslation: "Bonjour", level: "Beginner", topic: "Greetings" },
  { id: "b2", word: "Goodbye", definition: "A way of saying farewell", example: "Goodbye, see you tomorrow!", frenchTranslation: "Au revoir", level: "Beginner", topic: "Greetings" },
  { id: "b3", word: "Thank you", definition: "Expression of gratitude", example: "Thank you for your help.", frenchTranslation: "Merci", level: "Beginner", topic: "Greetings" },
  { id: "b4", word: "Please", definition: "Polite word used when requesting", example: "Please pass the salt.", frenchTranslation: "S'il vous plaît", level: "Beginner", topic: "Greetings" },
  { id: "b5", word: "Sorry", definition: "Expression of apology", example: "Sorry I am late.", frenchTranslation: "Pardon", level: "Beginner", topic: "Greetings" },
  // Family
  { id: "b6", word: "Mother", definition: "Female parent", example: "My mother is a teacher.", frenchTranslation: "Mère", level: "Beginner", topic: "Family" },
  { id: "b7", word: "Father", definition: "Male parent", example: "My father works in a bank.", frenchTranslation: "Père", level: "Beginner", topic: "Family" },
  { id: "b8", word: "Sister", definition: "Female sibling", example: "I have one sister.", frenchTranslation: "Sœur", level: "Beginner", topic: "Family" },
  { id: "b9", word: "Brother", definition: "Male sibling", example: "My brother is older than me.", frenchTranslation: "Frère", level: "Beginner", topic: "Family" },
  { id: "b10", word: "Friend", definition: "A person you know well and like", example: "She is my best friend.", frenchTranslation: "Ami", level: "Beginner", topic: "Family" },
  // Objects
  { id: "b11", word: "Book", definition: "A set of printed pages bound together", example: "I am reading a good book.", frenchTranslation: "Livre", level: "Beginner", topic: "Objects" },
  { id: "b12", word: "Table", definition: "Furniture with a flat top and legs", example: "Put the cup on the table.", frenchTranslation: "Table", level: "Beginner", topic: "Objects" },
  { id: "b13", word: "Chair", definition: "A seat for one person", example: "Please sit on the chair.", frenchTranslation: "Chaise", level: "Beginner", topic: "Objects" },
  { id: "b14", word: "Door", definition: "An entrance to a room or building", example: "Please close the door.", frenchTranslation: "Porte", level: "Beginner", topic: "Objects" },
  { id: "b15", word: "Window", definition: "An opening in a wall for light and air", example: "Open the window, please.", frenchTranslation: "Fenêtre", level: "Beginner", topic: "Objects" },
  // Numbers
  { id: "b16", word: "One", definition: "The number 1", example: "I have one cat.", frenchTranslation: "Un", level: "Beginner", topic: "Numbers" },
  { id: "b17", word: "Two", definition: "The number 2", example: "She has two children.", frenchTranslation: "Deux", level: "Beginner", topic: "Numbers" },
  { id: "b18", word: "Ten", definition: "The number 10", example: "There are ten students.", frenchTranslation: "Dix", level: "Beginner", topic: "Numbers" },
  { id: "b19", word: "Hundred", definition: "The number 100", example: "I have one hundred dollars.", frenchTranslation: "Cent", level: "Beginner", topic: "Numbers" },
  // Colors
  { id: "b20", word: "Red", definition: "The color of blood", example: "The apple is red.", frenchTranslation: "Rouge", level: "Beginner", topic: "Colors" },
  { id: "b21", word: "Blue", definition: "The color of the sky", example: "Her eyes are blue.", frenchTranslation: "Bleu", level: "Beginner", topic: "Colors" },
  { id: "b22", word: "Green", definition: "The color of grass", example: "The leaves are green.", frenchTranslation: "Vert", level: "Beginner", topic: "Colors" },
  { id: "b23", word: "Yellow", definition: "The color of the sun", example: "The sun is yellow.", frenchTranslation: "Jaune", level: "Beginner", topic: "Colors" },
  // Food
  { id: "b24", word: "Bread", definition: "A food made from flour and water", example: "I eat bread every morning.", frenchTranslation: "Pain", level: "Beginner", topic: "Food" },
  { id: "b25", word: "Water", definition: "A clear liquid that we drink", example: "Please give me some water.", frenchTranslation: "Eau", level: "Beginner", topic: "Food" },
  { id: "b26", word: "Milk", definition: "A white liquid from cows", example: "I drink milk for breakfast.", frenchTranslation: "Lait", level: "Beginner", topic: "Food" },
  { id: "b27", word: "Apple", definition: "A round red or green fruit", example: "An apple a day keeps the doctor away.", frenchTranslation: "Pomme", level: "Beginner", topic: "Food" },
  { id: "b28", word: "Rice", definition: "A food grain eaten around the world", example: "We had rice and chicken.", frenchTranslation: "Riz", level: "Beginner", topic: "Food" },

  // ===== INTERMEDIATE (23 words) =====
  // Travel
  { id: "i1", word: "Journey", definition: "An act of traveling from one place to another", example: "The journey to the mountains took five hours.", frenchTranslation: "Voyage", level: "Intermediate", topic: "Travel" },
  { id: "i2", word: "Airport", definition: "A place where airplanes take off and land", example: "We arrived at the airport two hours early.", frenchTranslation: "Aéroport", level: "Intermediate", topic: "Travel" },
  { id: "i3", word: "Passenger", definition: "A person traveling in a vehicle", example: "Each passenger must wear a seatbelt.", frenchTranslation: "Passager", level: "Intermediate", topic: "Travel" },
  { id: "i4", word: "Luggage", definition: "Bags and suitcases for travel", example: "Don't forget your luggage at the hotel.", frenchTranslation: "Bagages", level: "Intermediate", topic: "Travel" },
  { id: "i5", word: "Destination", definition: "The place where someone is going", example: "Paris is a popular tourist destination.", frenchTranslation: "Destination", level: "Intermediate", topic: "Travel" },
  // Work
  { id: "i6", word: "Career", definition: "A profession someone has for a long time", example: "She has a successful career in medicine.", frenchTranslation: "Carrière", level: "Intermediate", topic: "Work" },
  { id: "i7", word: "Meeting", definition: "An event where people discuss things", example: "We have a team meeting at 3 PM.", frenchTranslation: "Réunion", level: "Intermediate", topic: "Work" },
  { id: "i8", word: "Schedule", definition: "A plan that lists times and events", example: "Check the schedule for tomorrow's classes.", frenchTranslation: "Programme", level: "Intermediate", topic: "Work" },
  { id: "i9", word: "Deadline", definition: "The latest time something must be finished", example: "The deadline for the report is Friday.", frenchTranslation: "Échéance", level: "Intermediate", topic: "Work" },
  { id: "i10", word: "Office", definition: "A place where people work", example: "I left my keys at the office.", frenchTranslation: "Bureau", level: "Intermediate", topic: "Work" },
  // Daily life
  { id: "i11", word: "Morning", definition: "The early part of the day", example: "I drink coffee every morning.", frenchTranslation: "Matin", level: "Intermediate", topic: "Daily life" },
  { id: "i12", word: "Evening", definition: "The later part of the day", example: "We watch TV in the evening.", frenchTranslation: "Soir", level: "Intermediate", topic: "Daily life" },
  { id: "i13", word: "Weekend", definition: "Saturday and Sunday", example: "What are your plans for the weekend?", frenchTranslation: "Week-end", level: "Intermediate", topic: "Daily life" },
  { id: "i14", word: "Yesterday", definition: "The day before today", example: "Yesterday I went to the cinema.", frenchTranslation: "Hier", level: "Intermediate", topic: "Daily life" },
  { id: "i15", word: "Tomorrow", definition: "The day after today", example: "Tomorrow we have an exam.", frenchTranslation: "Demain", level: "Intermediate", topic: "Daily life" },
  // Health
  { id: "i16", word: "Doctor", definition: "A person who treats sick people", example: "You should see a doctor.", frenchTranslation: "Médecin", level: "Intermediate", topic: "Health" },
  { id: "i17", word: "Medicine", definition: "A substance used to treat illness", example: "Take this medicine after meals.", frenchTranslation: "Médicament", level: "Intermediate", topic: "Health" },
  { id: "i18", word: "Exercise", definition: "Physical activity to stay healthy", example: "Exercise is good for your heart.", frenchTranslation: "Exercice", level: "Intermediate", topic: "Health" },
  // Feelings
  { id: "i19", word: "Happy", definition: "Feeling pleasure or contentment", example: "She looks happy today.", frenchTranslation: "Heureux", level: "Intermediate", topic: "Feelings" },
  { id: "i20", word: "Sad", definition: "Feeling unhappy", example: "He felt sad when his friend left.", frenchTranslation: "Triste", level: "Intermediate", topic: "Feelings" },
  { id: "i21", word: "Tired", definition: "Feeling that you need to rest or sleep", example: "I am tired after a long day.", frenchTranslation: "Fatigué", level: "Intermediate", topic: "Feelings" },
  { id: "i22", word: "Excited", definition: "Very enthusiastic and eager", example: "The kids were excited about the trip.", frenchTranslation: "Excité", level: "Intermediate", topic: "Feelings" },
  { id: "i23", word: "Worried", definition: "Anxious or concerned", example: "She is worried about the test.", frenchTranslation: "Inquiet", level: "Intermediate", topic: "Feelings" },

  // ===== EXPERT (23 words) =====
  // Academic
  { id: "e1", word: "Hypothesis", definition: "A proposed explanation for a phenomenon", example: "The experiment confirmed our hypothesis.", frenchTranslation: "Hypothèse", level: "Expert", topic: "Academic" },
  { id: "e2", word: "Analysis", definition: "A detailed examination of something", example: "Her analysis of the data was thorough.", frenchTranslation: "Analyse", level: "Expert", topic: "Academic" },
  { id: "e3", word: "Theory", definition: "A well-substantiated explanation", example: "Einstein's theory changed physics.", frenchTranslation: "Théorie", level: "Expert", topic: "Academic" },
  { id: "e4", word: "Research", definition: "Systematic investigation to discover facts", example: "He published his research in a journal.", frenchTranslation: "Recherche", level: "Expert", topic: "Academic" },
  { id: "e5", word: "Conclusion", definition: "The end or final part of something", example: "In conclusion, the results support the claim.", frenchTranslation: "Conclusion", level: "Expert", topic: "Academic" },
  // Business
  { id: "e6", word: "Investment", definition: "Money put into something to make a profit", example: "The investment paid off after three years.", frenchTranslation: "Investissement", level: "Expert", topic: "Business" },
  { id: "e7", word: "Strategy", definition: "A plan to achieve a long-term goal", example: "Our marketing strategy is working well.", frenchTranslation: "Stratégie", level: "Expert", topic: "Business" },
  { id: "e8", word: "Negotiate", definition: "To discuss to reach an agreement", example: "They negotiated a lower price.", frenchTranslation: "Négocier", level: "Expert", topic: "Business" },
  { id: "e9", word: "Revenue", definition: "Income from business activities", example: "Company revenue grew by 20% this year.", frenchTranslation: "Revenu", level: "Expert", topic: "Business" },
  { id: "e10", word: "Stakeholder", definition: "A person with an interest in a business", example: "Every stakeholder should be informed.", frenchTranslation: "Partie prenante", level: "Expert", topic: "Business" },
  // Abstract
  { id: "e11", word: "Concept", definition: "An abstract idea", example: "Freedom is a complex concept.", frenchTranslation: "Concept", level: "Expert", topic: "Abstract" },
  { id: "e12", word: "Perspective", definition: "A particular way of viewing things", example: "From my perspective, the plan is good.", frenchTranslation: "Perspective", level: "Expert", topic: "Abstract" },
  { id: "e13", word: "Paradox", definition: "A statement that seems contradictory but may be true", example: "It's a paradox that more choice can mean less freedom.", frenchTranslation: "Paradoxe", level: "Expert", topic: "Abstract" },
  { id: "e14", word: "Paradigm", definition: "A typical example or pattern", example: "This discovery created a new paradigm.", frenchTranslation: "Paradigme", level: "Expert", topic: "Abstract" },
  { id: "e15", word: "Phenomenon", definition: "An observable event or fact", example: "Auroras are a beautiful natural phenomenon.", frenchTranslation: "Phénomène", level: "Expert", topic: "Abstract" },
  // Emotions (advanced)
  { id: "e16", word: "Empathy", definition: "The ability to understand others' feelings", example: "Good teachers have deep empathy.", frenchTranslation: "Empathie", level: "Expert", topic: "Emotions" },
  { id: "e17", word: "Resentment", definition: "Anger about something unfair", example: "He felt resentment toward his boss.", frenchTranslation: "Rancune", level: "Expert", topic: "Emotions" },
  { id: "e18", word: "Nostalgia", definition: "Longing for the past", example: "Old photos filled her with nostalgia.", frenchTranslation: "Nostalgie", level: "Expert", topic: "Emotions" },
  { id: "e19", word: "Awe", definition: "A feeling of respect mixed with wonder", example: "We looked at the mountains in awe.", frenchTranslation: "Émerveillement", level: "Expert", topic: "Emotions" },
  // Verbs (advanced)
  { id: "e20", word: "Anticipate", definition: "To expect something to happen", example: "We anticipate a rise in sales next quarter.", frenchTranslation: "Anticiper", level: "Expert", topic: "Verbs" },
  { id: "e21", word: "Comprehend", definition: "To fully understand", example: "I cannot comprehend his decision.", frenchTranslation: "Comprendre", level: "Expert", topic: "Verbs" },
  { id: "e22", word: "Elaborate", definition: "To explain in detail", example: "Could you elaborate on your idea?", frenchTranslation: "Développer", level: "Expert", topic: "Verbs" },
  { id: "e23", word: "Demonstrate", definition: "To show clearly", example: "She demonstrated how the machine works.", frenchTranslation: "Démontrer", level: "Expert", topic: "Verbs" },
]

// Pre-built topic groups for word lists
export const WORD_LIST_TOPICS = Array.from(new Set(VOCAB_WORDS.map(w => w.topic)))

export function wordsByLevel(level: "Beginner" | "Intermediate" | "Expert") {
  return VOCAB_WORDS.filter(w => w.level === level)
}
